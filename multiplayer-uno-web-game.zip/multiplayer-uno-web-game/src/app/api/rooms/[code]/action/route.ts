import { parseAction } from "@/lib/uno/room";
import { GameError, normalizeCode, performAction } from "@/lib/uno/store";

export const dynamic = "force-dynamic";

/** Любое действие игрока: POST { playerId, action } */
export async function POST(request: Request, ctx: { params: Promise<{ code: string }> }) {
  try {
    const { code: rawCode } = await ctx.params;
    const code = normalizeCode(rawCode);
    const body = (await request.json()) as { playerId?: unknown; action?: unknown };
    const playerId = typeof body.playerId === "string" ? body.playerId : "";
    if (playerId.length < 8 || playerId.length > 80) {
      return Response.json({ error: "Некорректный идентификатор игрока" }, { status: 400 });
    }
    const action = parseAction(body.action);
    if (!action) return Response.json({ error: "Неизвестное действие" }, { status: 400 });

    const result = await performAction(code, playerId, action);
    if (!result) return Response.json({ error: "Комната не найдена" }, { status: 404 });
    return Response.json({ view: result.view }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    if (error instanceof GameError) return Response.json({ error: error.message }, { status: 400 });
    console.error(error);
    return Response.json({ error: "Ошибка сервера" }, { status: 500 });
  }
}
