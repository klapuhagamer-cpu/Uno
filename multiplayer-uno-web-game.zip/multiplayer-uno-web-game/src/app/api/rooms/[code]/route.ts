import { getRoomView, normalizeCode } from "@/lib/uno/store";

export const dynamic = "force-dynamic";

/** Состояние комнаты: GET /api/rooms/ABCDE?playerId=... */
export async function GET(request: Request, ctx: { params: Promise<{ code: string }> }) {
  try {
    const { code: rawCode } = await ctx.params;
    const code = normalizeCode(rawCode);
    const playerId = new URL(request.url).searchParams.get("playerId");
    const view = await getRoomView(code, playerId);
    if (!view) return Response.json({ error: "Комната не найдена" }, { status: 404 });
    return Response.json(view, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error(error);
    return Response.json({ error: "Ошибка сервера" }, { status: 500 });
  }
}
