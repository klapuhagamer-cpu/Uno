import { cleanName } from "@/lib/uno/room";
import { GameError, createRoom } from "@/lib/uno/store";

export const dynamic = "force-dynamic";

/** Создать комнату: { name, playerId } -> { code } */
export async function POST(request: Request) {
  try {
    const body = (await request.json()) as { name?: unknown; playerId?: unknown };
    const name = typeof body.name === "string" ? cleanName(body.name) : "";
    const playerId = typeof body.playerId === "string" ? body.playerId : "";
    if (!name) return Response.json({ error: "Введите ник" }, { status: 400 });
    if (playerId.length < 8 || playerId.length > 80) {
      return Response.json({ error: "Некорректный идентификатор игрока" }, { status: 400 });
    }
    const code = await createRoom(playerId, name);
    return Response.json({ code });
  } catch (error) {
    if (error instanceof GameError) return Response.json({ error: error.message }, { status: 400 });
    console.error(error);
    return Response.json({ error: "Ошибка сервера" }, { status: 500 });
  }
}
