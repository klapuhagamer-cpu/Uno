import Entry from "@/components/Entry";

export default function HomePage() {
  return <Entry />;
}
