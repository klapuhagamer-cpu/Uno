"use client";

import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { ApiError, createRoomRequest, fetchRoomView } from "@/lib/client/api";
import { getPlayerId, getSavedName, saveName } from "@/lib/client/session";
import type { Card } from "@/lib/uno/types";
import { useAudioUnlock } from "./hooks";
import { UnoCard } from "./UnoCard";

const DECOR: { card: Card; rot: number; x: number; y: number }[] = [
  { card: { id: 1, color: "red", value: "7" }, rot: -24, x: -150, y: 20 },
  { card: { id: 2, color: "yellow", value: "skip" }, rot: -9, x: -52, y: -6 },
  { card: { id: 3, color: "green", value: "draw2" }, rot: 8, x: 52, y: -6 },
  { card: { id: 4, color: "wild", value: "wild4" }, rot: 22, x: 150, y: 20 },
];

export default function Entry() {
  const router = useRouter();
  useAudioUnlock();
  const [name, setName] = useState("");
  const [code, setCode] = useState("");
  const [busy, setBusy] = useState<"create" | "join" | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // localStorage доступен только в браузере, поэтому читаем ник уже после загрузки страницы
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setName(getSavedName());
  }, []);

  const cleanName = name.replace(/\s+/g, " ").trim();
  const cleanCode = code.toUpperCase().replace(/[^A-Z0-9]/g, "");

  const create = async () => {
    if (!cleanName) return setError("Сначала введите ник");
    setError(null);
    setBusy("create");
    try {
      saveName(cleanName);
      const roomCode = await createRoomRequest(cleanName, getPlayerId());
      router.push(`/room/${roomCode}`);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Не удалось создать комнату");
      setBusy(null);
    }
  };

  const join = async () => {
    if (!cleanName) return setError("Сначала введите ник");
    if (cleanCode.length < 4) return setError("Введите код комнаты");
    setError(null);
    setBusy("join");
    try {
      saveName(cleanName);
      await fetchRoomView(cleanCode, getPlayerId());
      router.push(`/room/${cleanCode}`);
    } catch (e) {
      setError(e instanceof ApiError && e.status === 404 ? "Комната с таким кодом не найдена" : "Не удалось подключиться");
      setBusy(null);
    }
  };

  return (
    <main className="arena-bg relative flex min-h-dvh flex-col items-center justify-center overflow-hidden px-4 py-10">
      {/* декоративные карты */}
      <div className="anim-float relative mb-2 h-[170px] w-full max-w-md">
        {DECOR.map((d) => (
          <div
            key={d.card.id}
            className="absolute left-1/2 top-0"
            style={{ transform: `translateX(calc(-50% + ${d.x}px)) translateY(${d.y}px) rotate(${d.rot}deg)` }}
          >
            <UnoCard card={d.card} w={92} />
          </div>
        ))}
      </div>

      <h1 className="shine-text text-center text-7xl font-black italic tracking-tight drop-shadow-2xl sm:text-8xl">УНО</h1>
      <p className="mb-8 mt-1 text-center text-sm font-semibold uppercase tracking-[0.35em] text-white/70">
        онлайн · боты · команды
      </p>

      <form
        className="glass anim-pop w-full max-w-md rounded-3xl p-6 shadow-[0_30px_80px_rgba(0,0,0,0.6)]"
        onSubmit={(e) => {
          e.preventDefault();
          if (cleanCode.length >= 4) void join();
          else void create();
        }}
      >
        <label className="block text-xs font-bold uppercase tracking-widest text-white/60">Ваш ник</label>
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          maxLength={16}
          placeholder="Например, Чемпион"
          autoFocus
          className="mt-1 w-full rounded-xl border border-white/15 bg-black/30 px-4 py-3 text-lg font-semibold outline-none transition placeholder:text-white/30 focus:border-fuchsia-400 focus:ring-2 focus:ring-fuchsia-500/40"
        />

        <button
          type="button"
          onClick={create}
          disabled={busy !== null}
          className="mt-5 w-full rounded-xl bg-gradient-to-r from-red-500 via-fuchsia-600 to-indigo-600 px-4 py-3.5 text-lg font-black uppercase tracking-wide shadow-lg shadow-fuchsia-900/40 transition hover:scale-[1.02] hover:brightness-110 active:scale-100 disabled:opacity-60"
        >
          {busy === "create" ? "Создаём…" : "✨ Создать комнату"}
        </button>

        <div className="my-5 flex items-center gap-3 text-xs uppercase tracking-widest text-white/40">
          <span className="h-px flex-1 bg-white/15" />
          или войти по коду
          <span className="h-px flex-1 bg-white/15" />
        </div>

        <div className="flex gap-2">
          <input
            value={code}
            onChange={(e) => setCode(e.target.value.toUpperCase())}
            maxLength={8}
            placeholder="КОД"
            className="min-w-0 flex-1 rounded-xl border border-white/15 bg-black/30 px-4 py-3 text-center text-xl font-black uppercase tracking-[0.4em] outline-none transition placeholder:tracking-widest placeholder:text-white/25 focus:border-sky-400 focus:ring-2 focus:ring-sky-500/40"
          />
          <button
            type="button"
            onClick={join}
            disabled={busy !== null}
            className="rounded-xl bg-sky-500 px-5 py-3 font-black uppercase tracking-wide text-white shadow-lg shadow-sky-900/40 transition hover:brightness-110 disabled:opacity-60"
          >
            {busy === "join" ? "…" : "Войти"}
          </button>
        </div>

        {error && (
          <p className="anim-shake mt-4 rounded-lg border border-red-400/40 bg-red-500/15 px-3 py-2 text-sm text-red-200">
            {error}
          </p>
        )}
      </form>

      <p className="mt-6 max-w-md text-center text-xs text-white/40">
        Играйте с друзьями по коду комнаты, добавляйте ботов, или сыграйте командами 2 на 2.
      </p>
    </main>
  );
}
