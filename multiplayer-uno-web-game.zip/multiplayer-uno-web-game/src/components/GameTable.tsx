"use client";

import { useEffect, useState } from "react";
import type { Card, ClientAction, Color, RoomView, SeatView } from "@/lib/uno/types";
import type { Banner } from "./hooks";
import { ColorPicker, Confetti, ResultModal, UnoBanner } from "./Overlays";
import SoundControls from "./SoundControls";
import { CardBack, COLOR_HEX, COLOR_NAME, UnoCard } from "./UnoCard";
import { Avatar, TEAM_STYLE } from "./ui";

interface GameTableProps {
  view: RoomView;
  act: (action: ClientAction) => void;
  busy: boolean;
  banner: Banner | null;
  lastCard: boolean;
  onLeave: () => void;
}

function useCardWidth() {
  const calc = () => {
    if (typeof window === "undefined") return 80;
    const w = window.innerWidth;
    return w < 420 ? 60 : w < 640 ? 68 : w < 1024 ? 80 : 92;
  };
  const [w, setW] = useState(calc);
  useEffect(() => {
    const onResize = () => setW(calc());
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, []);
  return w;
}

function Opponent({ seat, current, view }: { seat: SeatView; current: boolean; view: RoomView }) {
  const team = seat.team !== null ? TEAM_STYLE[seat.team] : null;
  const myTeam = view.youSeat !== null ? view.seats[view.youSeat].team : null;
  const ally = team !== null && myTeam === seat.team;
  const backs = Math.min(seat.cardCount, 7);

  return (
    <div
      className={`relative flex min-w-[104px] flex-col items-center gap-1 rounded-2xl px-3 pb-2 pt-3 transition ${
        current ? "anim-turn bg-yellow-300/20" : "bg-black/25"
      } ${seat.cardCount === 1 ? "ring-2 ring-red-500" : ""}`}
    >
      <div className="relative">
        <Avatar name={seat.name} kind={seat.kind} size={46} ringColor={current ? "#fde047" : team?.ring} />
        {team && (
          <span className={`absolute -right-2 -top-1 rounded-md px-1.5 text-[10px] font-black ${team.chip}`}>{team.short}</span>
        )}
      </div>
      <div className="max-w-[110px] truncate text-sm font-extrabold leading-tight">{seat.name}</div>
      <div className="h-3 text-[10px] font-bold uppercase tracking-wide text-white/60">
        {ally ? "союзник" : seat.away ? "нет связи" : seat.kind === "bot" ? "бот" : ""}
      </div>
      <div className="relative mt-1 flex h-[42px] items-end justify-center" style={{ width: 28 + backs * 11 }}>
        {Array.from({ length: backs }, (_, i) => (
          <CardBack
            key={i}
            w={28}
            className="absolute bottom-0"
            style={{ left: i * 11, transform: `rotate(${(i - (backs - 1) / 2) * 5}deg)` }}
          />
        ))}
      </div>
      <div
        className={`absolute -bottom-2 right-1 flex h-7 min-w-7 items-center justify-center rounded-full px-1.5 text-sm font-black shadow-lg ${
          seat.cardCount === 1 ? "animate-pulse bg-red-500 text-white" : "bg-white text-black"
        }`}
      >
        {seat.cardCount === 1 ? "УНО!" : seat.cardCount}
      </div>
    </div>
  );
}

export default function GameTable({ view, act, busy, banner, lastCard, onLeave }: GameTableProps) {
  const g = view.game!;
  const n = view.seats.length;
  const you = view.youSeat!;
  const myTurn = view.phase === "playing" && g.current === you;
  const cardW = useCardWidth();
  const [pendingWild, setPendingWild] = useState<Card | null>(null);

  // трясём экран, когда нам прилетел штраф (ключ меняется — анимация проигрывается заново)
  const lastEvent = view.events[view.events.length - 1];
  const shakeKey = lastEvent && lastEvent.type === "penalty" && lastEvent.seat === you ? lastEvent.id : 0;

  const opponents: SeatView[] = [];
  for (let k = 1; k < n; k++) opponents.push(view.seats[(you + k) % n]);

  const currentSeat = view.seats[g.current];
  const myTeam = view.seats[you].team;
  const overlap = g.hand.length <= 7 ? cardW * 0.12 : g.hand.length <= 11 ? cardW * 0.4 : cardW * 0.55;

  const playCard = (card: Card) => {
    if (!myTurn || busy || !g.playable.includes(card.id)) return;
    if (card.color === "wild") setPendingWild(card);
    else act({ type: "play", cardId: card.id });
  };

  const pickColor = (color: Color) => {
    if (!pendingWild) return;
    act({ type: "play", cardId: pendingWild.id, color });
    setPendingWild(null);
  };

  const hint = (() => {
    if (view.phase !== "playing") return "";
    if (!myTurn) return `Ходит ${currentSeat.name}…`;
    if (g.canPass) return "Сыграйте взятую карту или пропустите ход";
    if (g.penalty > 0) {
      return g.playable.length > 0 ? `Ответьте штрафом или возьмите ${g.penalty} карт` : `Придётся взять ${g.penalty} карт`;
    }
    if (g.playable.length === 0) return "Нет подходящих карт — тяните из колоды";
    return "Ваш ход!";
  })();

  const topRot = ((g.top.id * 37) % 17) - 8;
  const centerW = Math.round(cardW * 1.15);

  return (
    <main key={shakeKey} className={`game-bg relative flex min-h-dvh flex-col overflow-hidden ${shakeKey ? "anim-shake" : ""}`}>
      {/* тревожная пульсация, пока у кого-то одна карта */}
      {lastCard && <div className="alarm-vignette pointer-events-none fixed inset-0 z-[55]" />}

      {/* верхняя панель */}
      <header className="relative z-20 flex items-center justify-between gap-2 px-3 pt-3">
        <button type="button" onClick={onLeave} className="glass rounded-full px-4 py-2 text-xs font-bold transition hover:bg-white/15 sm:text-sm">
          ← Выйти
        </button>
        <div className="glass flex items-center gap-2 rounded-full px-4 py-2 text-xs font-bold sm:text-sm">
          <span className="text-white/60">Комната</span>
          <span className="tracking-[0.2em]">{view.code}</span>
          {view.settings.mode === "teams" && myTeam !== null && (
            <span className={`rounded-md px-2 py-0.5 text-[11px] font-black ${TEAM_STYLE[myTeam].chip}`}>
              {TEAM_STYLE[myTeam].label}
            </span>
          )}
        </div>
        <SoundControls />
      </header>

      {/* соперники */}
      <section className="relative z-10 mt-3 flex flex-wrap items-start justify-center gap-3 px-3 pb-3 sm:gap-5">
        {opponents.map((s) => (
          <Opponent key={s.index} seat={s} current={view.phase === "playing" && g.current === s.index} view={view} />
        ))}
      </section>

      {/* центр стола */}
      <section className="relative z-10 flex flex-1 flex-col items-center justify-center gap-4 px-3 py-2">
        <div
          className={`rounded-full px-5 py-1.5 text-sm font-black uppercase tracking-wider shadow-lg sm:text-base ${
            myTurn ? "anim-draw-pulse bg-yellow-300 text-black" : "bg-black/40 text-white/90"
          }`}
        >
          {hint || "Партия окончена"}
        </div>

        <div className="relative flex items-center justify-center gap-6 sm:gap-12">
          {/* колода */}
          <div className="flex flex-col items-center gap-2">
            <div className={g.canDraw && !busy ? "anim-draw-pulse" : ""}>
              <button
                type="button"
                disabled={!g.canDraw || busy}
                onClick={() => act({ type: "draw" })}
                className="relative block disabled:cursor-default"
                aria-label="Взять карту"
              >
                <CardBack w={centerW} glow={g.canDraw && !busy} className="absolute left-1.5 top-1.5 opacity-60" />
                <CardBack w={centerW} glow={g.canDraw && !busy} className={g.canDraw ? "cursor-pointer" : ""} />
              </button>
            </div>
            <span className="rounded-full bg-black/40 px-3 py-0.5 text-xs font-bold text-white/80">
              {g.penalty > 0 && g.canDraw ? `Взять ${g.penalty}` : `Колода · ${g.drawCount}`}
            </span>
          </div>

          {/* сброс */}
          <div className="relative flex flex-col items-center gap-2">
            <div className="relative flex items-center justify-center" style={{ width: centerW * 1.6, height: centerW * 1.9 }}>
              <div
                className={`absolute inset-0 rounded-full border-[5px] border-dashed opacity-70 ${g.direction === 1 ? "anim-spin-slow" : "anim-spin-slow-rev"}`}
                style={{ borderColor: COLOR_HEX[g.color], boxShadow: `0 0 50px 8px ${COLOR_HEX[g.color]}66, inset 0 0 50px 8px ${COLOR_HEX[g.color]}44` }}
              />
              <div key={g.top.id} className="anim-card-drop relative" style={{ ["--rot" as string]: `${topRot}deg` }}>
                <UnoCard card={g.top} w={centerW} glow />
              </div>
              {g.penalty > 0 && (
                <div className="anim-pop absolute -right-1 -top-1 flex h-14 w-14 items-center justify-center rounded-full border-4 border-white bg-red-600 text-xl font-black shadow-xl">
                  +{g.penalty}
                </div>
              )}
            </div>
            <span
              className="flex items-center gap-2 rounded-full bg-black/45 px-3 py-0.5 text-xs font-bold"
              title="Текущий цвет и направление хода"
            >
              <span className="inline-block h-3 w-3 rounded-full border border-white" style={{ background: COLOR_HEX[g.color] }} />
              {COLOR_NAME[g.color]} · {g.direction === 1 ? "↻" : "↺"}
            </span>
          </div>
        </div>

        {/* последние события */}
        <div className="flex min-h-[3.2rem] w-full max-w-md flex-col items-center gap-0.5 text-center text-xs text-white/80 sm:text-sm">
          {view.events
            .slice(-3)
            .reverse()
            .map((e, i) => (
              <div key={e.id} className="rounded-full bg-black/30 px-3 py-0.5" style={{ opacity: 1 - i * 0.3 }}>
                {e.text}
              </div>
            ))}
        </div>
      </section>

      {/* рука игрока */}
      <section className="relative z-20 mt-auto bg-gradient-to-t from-black/70 via-black/35 to-transparent px-2 pb-3 pt-2">
        <div className="mb-1 flex items-center justify-center gap-3">
          {g.canPass && (
            <button
              type="button"
              disabled={busy}
              onClick={() => act({ type: "pass" })}
              className="anim-pop rounded-full bg-white px-6 py-2 text-sm font-black uppercase text-black shadow-lg transition hover:scale-105 disabled:opacity-60"
            >
              Пропустить ход
            </button>
          )}
          <span className="rounded-full bg-black/40 px-3 py-1 text-xs font-bold text-white/70">
            Ваши карты: {g.hand.length}
          </span>
        </div>
        <div className="overflow-x-auto overflow-y-visible pb-1 pt-8">
          <div className="mx-auto flex w-max items-end px-4">
            {g.hand.map((card, i) => {
              const playable = myTurn && g.playable.includes(card.id);
              const isDrawn = g.drawnId === card.id;
              return (
                <div
                  key={card.id}
                  className="anim-deal relative"
                  style={{ marginLeft: i === 0 ? 0 : -overlap, zIndex: i, animationDelay: `${Math.min(i, 8) * 25}ms` }}
                >
                  <UnoCard
                    card={card}
                    w={cardW}
                    playable={playable}
                    dim={myTurn && !playable}
                    glow={isDrawn}
                    onClick={playable ? () => playCard(card) : undefined}
                  />
                </div>
              );
            })}
          </div>
        </div>
      </section>

      <UnoBanner banner={banner} />
      {pendingWild && <ColorPicker onPick={pickColor} onCancel={() => setPendingWild(null)} />}
      {view.phase === "finished" && (
        <>
          <ResultModal view={view} act={act} busy={busy} onLeave={onLeave} />
          {(() => {
            const w = g.winner !== null ? view.seats[g.winner] : null;
            const mine = view.seats[you];
            const won = !!w && (w.index === you || (g.winnerTeam !== null && g.winnerTeam === mine.team));
            return won ? <Confetti /> : null;
          })()}
        </>
      )}
    </main>
  );
}
