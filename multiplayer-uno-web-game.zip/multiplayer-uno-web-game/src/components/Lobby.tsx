"use client";

import { useState } from "react";
import type { BotLevel, ClientAction, Mode, RoomView, SeatView } from "@/lib/uno/types";
import SoundControls from "./SoundControls";
import { Avatar, Segmented, TEAM_STYLE } from "./ui";

interface LobbyProps {
  view: RoomView;
  act: (action: ClientAction) => void;
  busy: boolean;
  onLeave: () => void;
}

/** Какие места открыть для людей, чтобы всего было `wantHumans` игроков */
function presetOpen(view: RoomView, wantHumans: number, mode: Mode): number[] {
  const total = 4;
  const humanSeats = view.seats.slice(0, total).filter((s) => s.kind === "human").map((s) => s.index);
  const need = Math.max(0, wantHumans - humanSeats.length);
  let candidates = Array.from({ length: total }, (_, i) => i).filter((i) => !humanSeats.includes(i));
  if (mode === "teams" && wantHumans === 2 && view.youSeat !== null) {
    // друг должен быть в одной команде с вами
    const mine = view.youSeat % 2;
    candidates = [...candidates.filter((i) => i % 2 === mine), ...candidates.filter((i) => i % 2 !== mine)];
  }
  return candidates.slice(0, need);
}

function SeatCard({ seat, view, act, busy }: { seat: SeatView; view: RoomView; act: LobbyProps["act"]; busy: boolean }) {
  const youAreHost = view.youSeat === view.hostSeat;
  const team = seat.team !== null ? TEAM_STYLE[seat.team] : null;
  const label = seat.kind === "human" ? (seat.isHost ? "Хозяин комнаты" : "Игрок") : seat.kind === "bot" ? "Бот" : "Ждём игрока…";

  return (
    <div
      className={`anim-pop relative flex flex-col gap-3 rounded-2xl border bg-gradient-to-br p-4 ${
        team ? team.panel : "border-white/15 from-white/10 to-white/5"
      } ${seat.isYou ? "ring-2 ring-yellow-300/80" : ""}`}
    >
      <div className="flex items-center gap-3">
        <Avatar name={seat.name} kind={seat.kind} size={52} ringColor={team?.ring} />
        <div className="min-w-0 flex-1">
          <div className="truncate text-lg font-extrabold leading-tight">
            {seat.kind === "open" ? "Свободно" : seat.name}
            {seat.isYou && <span className="ml-2 rounded bg-yellow-300 px-1.5 py-0.5 text-[10px] font-black uppercase text-black">вы</span>}
          </div>
          <div className="text-xs text-white/60">
            {seat.isHost && "👑 "}
            {label}
            {seat.away && " · нет связи"}
          </div>
        </div>
        {team && <span className={`rounded-lg px-2 py-1 text-xs font-black ${team.chip}`}>{team.short}</span>}
      </div>

      <div className="flex flex-wrap gap-2">
        {seat.kind !== "human" && (
          <button
            type="button"
            disabled={busy}
            onClick={() => act({ type: "sit", index: seat.index })}
            className="rounded-lg bg-white/15 px-3 py-1.5 text-xs font-bold transition hover:bg-white/25 disabled:opacity-50"
          >
            Сесть сюда
          </button>
        )}
        {youAreHost && !seat.isYou && seat.kind !== "human" && (
          <>
            <button
              type="button"
              disabled={busy || seat.kind === "bot"}
              onClick={() => act({ type: "seat", index: seat.index, kind: "bot" })}
              className={`rounded-lg px-3 py-1.5 text-xs font-bold transition disabled:opacity-100 ${
                seat.kind === "bot" ? "bg-indigo-500 text-white" : "bg-white/10 hover:bg-white/20"
              }`}
            >
              🤖 Бот
            </button>
            <button
              type="button"
              disabled={busy || seat.kind === "open"}
              onClick={() => act({ type: "seat", index: seat.index, kind: "open" })}
              className={`rounded-lg px-3 py-1.5 text-xs font-bold transition disabled:opacity-100 ${
                seat.kind === "open" ? "bg-emerald-500 text-white" : "bg-white/10 hover:bg-white/20"
              }`}
            >
              👤 Для игрока
            </button>
          </>
        )}
        {youAreHost && !seat.isYou && seat.kind === "human" && (
          <button
            type="button"
            disabled={busy}
            onClick={() => act({ type: "seat", index: seat.index, kind: "open" })}
            className="rounded-lg bg-red-500/80 px-3 py-1.5 text-xs font-bold transition hover:bg-red-500 disabled:opacity-50"
          >
            Исключить
          </button>
        )}
      </div>
    </div>
  );
}

export default function Lobby({ view, act, busy, onLeave }: LobbyProps) {
  const [copied, setCopied] = useState<"code" | "link" | null>(null);
  const youAreHost = view.youSeat === view.hostSeat;
  const { settings, seats } = view;
  const humans = seats.filter((s) => s.kind === "human").length;
  const bots = seats.filter((s) => s.kind === "bot").length;
  const open = seats.filter((s) => s.kind === "open").length;
  const teams = settings.mode === "teams";

  const copy = async (what: "code" | "link") => {
    const text = what === "code" ? view.code : `${window.location.origin}/room/${view.code}`;
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      const el = document.createElement("textarea");
      el.value = text;
      document.body.appendChild(el);
      el.select();
      document.execCommand("copy");
      el.remove();
    }
    setCopied(what);
    setTimeout(() => setCopied(null), 1500);
  };

  const preset = (mode: Mode, wantHumans: number) =>
    act({ type: "preset", mode, seatCount: 4, open: presetOpen(view, wantHumans, mode) });

  const presetBtn = "rounded-xl bg-white/10 px-3 py-2 text-left text-xs font-bold transition hover:bg-white/20 disabled:opacity-50 sm:text-sm";

  return (
    <main className="arena-bg min-h-dvh px-4 pb-16 pt-4">
      <div className="mx-auto max-w-5xl">
        <header className="flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={onLeave}
            className="glass rounded-full px-4 py-2 text-sm font-bold transition hover:bg-white/15"
          >
            ← Выйти
          </button>
          <h1 className="shine-text text-3xl font-black italic">УНО</h1>
          <SoundControls />
        </header>

        {/* код комнаты */}
        <section className="glass anim-pop mt-5 flex flex-col items-center gap-3 rounded-3xl p-6 text-center">
          <div className="text-xs font-bold uppercase tracking-[0.3em] text-white/60">Код комнаты</div>
          <div className="text-glow select-all text-6xl font-black tracking-[0.25em] sm:text-7xl">{view.code}</div>
          <div className="flex flex-wrap justify-center gap-2">
            <button
              type="button"
              onClick={() => copy("code")}
              className="rounded-xl bg-white/15 px-4 py-2 text-sm font-bold transition hover:bg-white/25"
            >
              {copied === "code" ? "✓ Скопировано" : "📋 Скопировать код"}
            </button>
            <button
              type="button"
              onClick={() => copy("link")}
              className="rounded-xl bg-white/15 px-4 py-2 text-sm font-bold transition hover:bg-white/25"
            >
              {copied === "link" ? "✓ Скопировано" : "🔗 Ссылка-приглашение"}
            </button>
          </div>
          <p className="text-xs text-white/50">Друзья вводят этот код на главной странице и садятся на свободные места.</p>
        </section>

        <div className="mt-5 grid gap-5 lg:grid-cols-[1.5fr_1fr]">
          {/* места */}
          <section className="glass rounded-3xl p-5">
            <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
              <h2 className="text-lg font-black uppercase tracking-wide">
                {teams ? "Команды 2 × 2" : "Игроки"}
              </h2>
              <div className="flex gap-2 text-xs font-bold">
                <span className="rounded-full bg-emerald-500/25 px-3 py-1">👤 {humans}</span>
                <span className="rounded-full bg-indigo-500/25 px-3 py-1">🤖 {bots}</span>
                {open > 0 && <span className="rounded-full bg-white/10 px-3 py-1">⏳ свободно {open}</span>}
              </div>
            </div>

            {teams ? (
              <div className="grid gap-3">
                {[0, 1].map((t) => (
                  <div key={t}>
                    <div className={`mb-2 text-sm font-black uppercase tracking-widest ${TEAM_STYLE[t].text}`}>
                      {TEAM_STYLE[t].label}
                    </div>
                    <div className="grid gap-3 sm:grid-cols-2">
                      {seats
                        .filter((s) => s.team === t)
                        .map((s) => (
                          <SeatCard key={s.index} seat={s} view={view} act={act} busy={busy} />
                        ))}
                    </div>
                    {t === 0 && <div className="my-3 text-center text-2xl font-black text-white/40">VS</div>}
                  </div>
                ))}
                <p className="text-xs text-white/50">
                  Если один из команды сбросит все карты — побеждает вся команда. Сидите так, чтобы союзник был напротив: ходы идут по кругу.
                </p>
              </div>
            ) : (
              <div className="grid gap-3 sm:grid-cols-2">
                {seats.map((s) => (
                  <SeatCard key={s.index} seat={s} view={view} act={act} busy={busy} />
                ))}
              </div>
            )}
          </section>

          {/* настройки */}
          <section className="glass flex flex-col gap-5 rounded-3xl p-5">
            <div>
              <h2 className="mb-2 text-lg font-black uppercase tracking-wide">Режим</h2>
              <Segmented<Mode>
                value={settings.mode}
                disabled={!youAreHost || busy}
                onChange={(mode) => act({ type: "configure", mode })}
                options={[
                  { value: "ffa", label: "Каждый за себя" },
                  { value: "teams", label: "Команды 2×2" },
                ]}
              />
            </div>

            {!teams && (
              <div>
                <h2 className="mb-2 text-sm font-black uppercase tracking-wide text-white/70">Количество мест</h2>
                <Segmented<number>
                  value={settings.seatCount}
                  disabled={!youAreHost || busy}
                  onChange={(seatCount) => act({ type: "configure", seatCount })}
                  options={[2, 3, 4, 5, 6].map((n) => ({ value: n, label: String(n) }))}
                />
              </div>
            )}

            <div>
              <h2 className="mb-2 text-sm font-black uppercase tracking-wide text-white/70">Сложность ботов</h2>
              <Segmented<BotLevel>
                value={settings.botLevel}
                disabled={!youAreHost || busy}
                onChange={(botLevel) => act({ type: "configure", botLevel })}
                options={[
                  { value: "easy", label: "Лёгкие" },
                  { value: "normal", label: "Средние" },
                  { value: "hard", label: "Хитрые" },
                ]}
              />
            </div>

            <label className="flex items-center justify-between gap-3 rounded-xl bg-black/25 px-4 py-3">
              <span>
                <span className="block text-sm font-bold">Складывать штрафы</span>
                <span className="block text-xs text-white/50">+2 на +2, +4 на любой штраф</span>
              </span>
              <input
                type="checkbox"
                checked={settings.stacking}
                disabled={!youAreHost || busy}
                onChange={(e) => act({ type: "configure", stacking: e.target.checked })}
                className="h-6 w-6 accent-fuchsia-500"
              />
            </label>

            {youAreHost && (
              <div>
                <h2 className="mb-2 text-sm font-black uppercase tracking-wide text-white/70">Быстрый выбор</h2>
                <div className="grid grid-cols-2 gap-2">
                  <button type="button" disabled={busy} className={presetBtn} onClick={() => preset("ffa", 1)}>
                    🧍 Я + боты
                  </button>
                  <button type="button" disabled={busy} className={presetBtn} onClick={() => preset("ffa", 2)}>
                    👥 2 игрока + боты
                  </button>
                  <button type="button" disabled={busy} className={presetBtn} onClick={() => preset("ffa", 3)}>
                    👥 3 игрока + бот
                  </button>
                  <button type="button" disabled={busy} className={presetBtn} onClick={() => preset("ffa", 4)}>
                    🎉 4 игрока
                  </button>
                  <button type="button" disabled={busy} className={presetBtn} onClick={() => preset("teams", 1)}>
                    ⚔️ 2×2: я + бот
                  </button>
                  <button type="button" disabled={busy} className={presetBtn} onClick={() => preset("teams", 2)}>
                    ⚔️ 2×2: я + друг
                  </button>
                  <button type="button" disabled={busy} className={`${presetBtn} col-span-2`} onClick={() => preset("teams", 4)}>
                    ⚔️ 2×2: четыре игрока
                  </button>
                </div>
              </div>
            )}

            {!youAreHost && (
              <p className="rounded-xl bg-black/25 px-4 py-3 text-sm text-white/70">
                Настройки меняет хозяин комнаты. Вы можете выбрать место кнопкой «Сесть сюда».
              </p>
            )}
          </section>
        </div>

        <div className="mt-6 flex flex-col items-center gap-2">
          {youAreHost ? (
            <>
              <button
                type="button"
                disabled={busy}
                onClick={() => act({ type: "start" })}
                className="rounded-2xl bg-gradient-to-r from-red-500 via-orange-500 to-yellow-400 px-10 py-4 text-xl font-black uppercase tracking-wide text-black shadow-[0_10px_40px_rgba(251,146,60,0.45)] transition hover:scale-105 active:scale-100 disabled:opacity-60"
              >
                🚀 Начать игру
              </button>
              {open > 0 && (
                <p className="text-xs text-white/50">
                  Свободные места ({open}) займут боты. Если ждёте друзей — подождите, пока все сядут.
                </p>
              )}
            </>
          ) : (
            <div className="glass rounded-2xl px-6 py-4 text-center text-sm font-semibold text-white/80">
              ⏳ Ждём, пока хозяин комнаты начнёт игру…
            </div>
          )}
        </div>
      </div>
    </main>
  );
}
