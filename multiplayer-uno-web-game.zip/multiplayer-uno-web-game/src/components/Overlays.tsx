"use client";

import type { ClientAction, Color, RoomView } from "@/lib/uno/types";
import type { Banner } from "./hooks";
import { COLOR_HEX, COLOR_NAME, UnoCard } from "./UnoCard";
import { Avatar, TEAM_STYLE } from "./ui";

export function UnoBanner({ banner }: { banner: Banner | null }) {
  if (!banner) return null;
  return (
    <div className="pointer-events-none fixed inset-0 z-[70] flex items-center justify-center">
      <div key={banner.id} className="anim-uno text-center">
        <div
          className="text-[clamp(5rem,22vw,13rem)] font-black italic leading-none"
          style={{
            background: "linear-gradient(180deg,#fff7ad 0%,#ffd000 45%,#ff3d3d 100%)",
            WebkitBackgroundClip: "text",
            backgroundClip: "text",
            color: "transparent",
            filter: "drop-shadow(0 0 28px rgba(255,80,80,0.9)) drop-shadow(0 8px 0 rgba(0,0,0,0.5))",
            WebkitTextStroke: "3px rgba(0,0,0,0.35)",
          }}
        >
          УНО!
        </div>
        {banner.name && (
          <div className="mt-2 text-2xl font-black uppercase tracking-widest text-white drop-shadow-[0_2px_8px_rgba(0,0,0,0.9)] sm:text-4xl">
            {banner.name}: одна карта!
          </div>
        )}
      </div>
    </div>
  );
}

const CONFETTI_COLORS = ["#ef3340", "#facc15", "#22b35e", "#2f6bff", "#f472b6", "#ffffff"];

export function Confetti() {
  const pieces = Array.from({ length: 70 }, (_, i) => {
    const r1 = Math.abs(Math.sin(i * 12.9898) * 43758.5453) % 1;
    const r2 = Math.abs(Math.sin(i * 78.233) * 12345.6789) % 1;
    const r3 = Math.abs(Math.sin(i * 39.346) * 9876.5432) % 1;
    return {
      left: `${r1 * 100}%`,
      delay: `${-r2 * 6}s`,
      duration: `${3.5 + r3 * 3}s`,
      dx: `${(r2 - 0.5) * 220}px`,
      color: CONFETTI_COLORS[i % CONFETTI_COLORS.length],
      rot: `${r3 * 360}deg`,
    };
  });
  return (
    <div className="pointer-events-none fixed inset-0 z-[60] overflow-hidden">
      {pieces.map((p, i) => (
        <span
          key={i}
          className="confetti-piece"
          style={
            {
              left: p.left,
              background: p.color,
              animationDelay: p.delay,
              animationDuration: p.duration,
              "--dx": p.dx,
              rotate: p.rot,
            } as React.CSSProperties
          }
        />
      ))}
    </div>
  );
}

export function ColorPicker({ onPick, onCancel }: { onPick: (c: Color) => void; onCancel: () => void }) {
  const colors: Color[] = ["red", "yellow", "green", "blue"];
  return (
    <div className="fixed inset-0 z-[90] flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm" onClick={onCancel}>
      <div className="anim-pop glass w-full max-w-sm rounded-3xl p-6 text-center" onClick={(e) => e.stopPropagation()}>
        <h3 className="text-2xl font-black uppercase tracking-wide">Выберите цвет</h3>
        <div className="mt-5 grid grid-cols-2 gap-4">
          {colors.map((c) => (
            <button
              key={c}
              type="button"
              onClick={() => onPick(c)}
              className="h-24 rounded-2xl border-4 border-white/90 text-lg font-black uppercase text-white shadow-xl transition hover:scale-105 active:scale-95"
              style={{ background: COLOR_HEX[c], textShadow: "0 2px 4px rgba(0,0,0,0.5)" }}
            >
              {COLOR_NAME[c]}
            </button>
          ))}
        </div>
        <button type="button" onClick={onCancel} className="mt-5 text-sm font-semibold text-white/60 hover:text-white">
          Отмена
        </button>
      </div>
    </div>
  );
}

export function ResultModal({
  view,
  act,
  busy,
  onLeave,
}: {
  view: RoomView;
  act: (a: ClientAction) => void;
  busy: boolean;
  onLeave: () => void;
}) {
  const g = view.game!;
  const youAreHost = view.youSeat === view.hostSeat;
  const winnerSeat = g.winner !== null ? view.seats[g.winner] : null;
  const me = view.youSeat !== null ? view.seats[view.youSeat] : null;
  const won =
    !!winnerSeat && !!me && (winnerSeat.index === me.index || (g.winnerTeam !== null && g.winnerTeam === me.team));
  const teamStyle = g.winnerTeam !== null ? TEAM_STYLE[g.winnerTeam] : null;

  return (
    <div className="fixed inset-0 z-[75] flex items-center justify-center overflow-y-auto bg-black/65 p-4 backdrop-blur-sm">
      <div className="anim-pop glass my-auto w-full max-w-2xl rounded-3xl p-6 text-center shadow-2xl">
        <div className="text-6xl">{won ? "🏆" : "💀"}</div>
        <h2 className={`mt-2 text-4xl font-black uppercase italic ${won ? "shine-text" : "text-white/90"}`}>
          {won ? "Победа!" : "Поражение"}
        </h2>
        <p className="mt-2 text-lg font-semibold">
          {teamStyle ? (
            <>
              Побеждает <span className={teamStyle.text}>{teamStyle.label}</span>
              {winnerSeat && <span className="text-white/70"> — карты сбросил {winnerSeat.name}</span>}
            </>
          ) : (
            <>Выигрывает {winnerSeat?.name}</>
          )}
        </p>
        <p className="mt-1 text-sm text-white/60">Очков за раунд: {g.points}</p>

        {g.finalHands && (
          <div className="mt-5 grid gap-2 text-left">
            {view.seats.map((s) => {
              const hand = g.finalHands![s.index];
              const team = s.team !== null ? TEAM_STYLE[s.team] : null;
              const isWinner = s.index === g.winner;
              return (
                <div
                  key={s.index}
                  className={`flex items-center gap-3 rounded-xl border bg-black/25 px-3 py-2 ${
                    isWinner ? "border-yellow-300/80" : "border-white/10"
                  }`}
                >
                  <Avatar name={s.name} kind={s.kind} size={34} ringColor={team?.ring} />
                  <div className="w-24 shrink-0 truncate text-sm font-bold sm:w-32">
                    {s.name}
                    {isWinner && " 👑"}
                  </div>
                  <div className="flex min-w-0 flex-1 gap-1 overflow-x-auto py-1">
                    {hand.length === 0 ? (
                      <span className="text-xs font-semibold text-emerald-300">Карт нет!</span>
                    ) : (
                      hand.map((c) => <UnoCard key={c.id} card={c} w={30} />)
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        <div className="mt-6 flex flex-col items-center gap-3 sm:flex-row sm:justify-center">
          {youAreHost ? (
            <>
              <button
                type="button"
                disabled={busy}
                onClick={() => act({ type: "rematch", startNow: true })}
                className="rounded-xl bg-gradient-to-r from-red-500 to-yellow-400 px-6 py-3 font-black uppercase text-black shadow-lg transition hover:scale-105 disabled:opacity-60"
              >
                🔁 Сыграть ещё
              </button>
              <button
                type="button"
                disabled={busy}
                onClick={() => act({ type: "rematch", startNow: false })}
                className="rounded-xl bg-white/15 px-6 py-3 font-bold transition hover:bg-white/25 disabled:opacity-60"
              >
                В лобби
              </button>
            </>
          ) : (
            <span className="text-sm text-white/70">Ждём решения хозяина комнаты…</span>
          )}
          <button type="button" onClick={onLeave} className="rounded-xl px-4 py-3 text-sm font-semibold text-white/60 transition hover:text-white">
            Выйти из комнаты
          </button>
        </div>
      </div>
    </div>
  );
}
