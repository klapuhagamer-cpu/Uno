"use client";

import { useRouter } from "next/navigation";
import { useCallback, useEffect, useRef, useState } from "react";
import { ApiError, fetchRoomView, sendAction } from "@/lib/client/api";
import { getPlayerId, getSavedName, saveName } from "@/lib/client/session";
import type { ClientAction, RoomView } from "@/lib/uno/types";
import GameTable from "./GameTable";
import { useAudioUnlock, useGameFx } from "./hooks";
import Lobby from "./Lobby";

const POLL_MS = 800;

function versionOf(v: RoomView): number {
  return Number.parseInt(v.stamp, 10) || 0;
}

function Centered({ children }: { children: React.ReactNode }) {
  return <main className="arena-bg flex min-h-dvh flex-col items-center justify-center gap-4 px-4 text-center">{children}</main>;
}

export default function RoomClient({ code }: { code: string }) {
  const router = useRouter();
  useAudioUnlock();

  const [playerId, setPlayerId] = useState("");
  const [view, setView] = useState<RoomView | null>(null);
  const [fatal, setFatal] = useState<string | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [name, setName] = useState("");
  const [joinError, setJoinError] = useState<string | null>(null);

  const [wasSeated, setWasSeated] = useState(false);
  const everSeated = useRef(false);
  const autoJoinTried = useRef(false);
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const { banner, lastCard } = useGameFx(view);

  const apply = useCallback((incoming: RoomView) => {
    if (incoming.youSeat !== null) {
      everSeated.current = true;
      setWasSeated(true);
    }
    setView((prev) => {
      if (prev && prev.code === incoming.code) {
        if (versionOf(incoming) < versionOf(prev)) return prev;
        if (incoming.stamp === prev.stamp) return prev;
      }
      return incoming;
    });
  }, []);

  const showToast = useCallback((message: string) => {
    setToast(message);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(null), 3200);
  }, []);

  useEffect(() => {
    // sessionStorage / localStorage есть только в браузере — читаем после загрузки страницы
    /* eslint-disable react-hooks/set-state-in-effect */
    setPlayerId(getPlayerId());
    setName(getSavedName());
    /* eslint-enable react-hooks/set-state-in-effect */
    return () => {
      if (toastTimer.current) clearTimeout(toastTimer.current);
    };
  }, []);

  // опрос состояния комнаты
  useEffect(() => {
    if (!playerId) return;
    let stopped = false;
    let timer: ReturnType<typeof setTimeout> | undefined;

    const tick = async () => {
      try {
        const v = await fetchRoomView(code, playerId);
        if (stopped) return;
        setFatal(null);
        apply(v);
      } catch (e) {
        if (stopped) return;
        if (e instanceof ApiError && e.status === 404) setFatal("Комната не найдена или была закрыта");
      } finally {
        if (!stopped) timer = setTimeout(tick, POLL_MS);
      }
    };
    void tick();
    return () => {
      stopped = true;
      if (timer) clearTimeout(timer);
    };
  }, [code, playerId, apply]);

  const act = useCallback(
    async (action: ClientAction) => {
      if (!playerId) return;
      setBusy(true);
      try {
        const v = await sendAction(code, playerId, action);
        if (v) apply(v);
      } catch (e) {
        showToast(e instanceof Error ? e.message : "Что-то пошло не так");
      } finally {
        setBusy(false);
      }
    },
    [apply, code, playerId, showToast],
  );

  const join = useCallback(
    async (nick: string) => {
      const clean = nick.replace(/\s+/g, " ").trim();
      if (!clean) {
        setJoinError("Введите ник");
        return;
      }
      saveName(clean);
      setJoinError(null);
      setBusy(true);
      try {
        const v = await sendAction(code, playerId, { type: "join", name: clean });
        if (v) apply(v);
      } catch (e) {
        setJoinError(e instanceof Error ? e.message : "Не удалось войти");
      } finally {
        setBusy(false);
      }
    },
    [apply, code, playerId],
  );

  // Автоматический вход, если ник уже известен
  const seated = view?.youSeat !== null && view?.youSeat !== undefined;
  const viewLoaded = view !== null;
  useEffect(() => {
    if (!viewLoaded || seated || autoJoinTried.current || everSeated.current || !playerId) return;
    autoJoinTried.current = true;
    // eslint-disable-next-line react-hooks/set-state-in-effect
    if (name.trim()) void join(name);
  }, [viewLoaded, seated, playerId, name, join]);

  const leave = useCallback(async () => {
    try {
      await sendAction(code, playerId, { type: "leave" });
    } catch {
      /* всё равно уходим */
    }
    router.push("/");
  }, [code, playerId, router]);

  if (fatal) {
    return (
      <Centered>
        <div className="text-6xl">🃏</div>
        <h1 className="text-2xl font-black">{fatal}</h1>
        <button
          type="button"
          onClick={() => router.push("/")}
          className="rounded-xl bg-gradient-to-r from-fuchsia-600 to-indigo-600 px-6 py-3 font-black uppercase shadow-lg transition hover:brightness-110"
        >
          На главную
        </button>
      </Centered>
    );
  }

  if (!view) {
    return (
      <Centered>
        <div className="anim-float text-6xl">🃏</div>
        <p className="font-semibold text-white/70">Подключаемся к комнате {code}…</p>
      </Centered>
    );
  }

  if (view.youSeat === null) {
    const wasKicked = wasSeated;
    return (
      <Centered>
        <div className="glass anim-pop w-full max-w-sm rounded-3xl p-6">
          <div className="text-xs font-bold uppercase tracking-[0.3em] text-white/60">Комната</div>
          <div className="text-glow text-5xl font-black tracking-[0.25em]">{view.code}</div>
          <p className="mt-3 text-sm text-white/70">
            {wasKicked
              ? "Вы больше не за столом. Можно войти снова."
              : view.phase === "lobby"
                ? "Введите ник, чтобы присоединиться."
                : "В этой комнате уже идёт игра. Дождитесь её окончания."}
          </p>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            maxLength={16}
            placeholder="Ваш ник"
            className="mt-4 w-full rounded-xl border border-white/15 bg-black/30 px-4 py-3 text-center text-lg font-semibold outline-none focus:border-fuchsia-400"
            onKeyDown={(e) => {
              if (e.key === "Enter") void join(name);
            }}
          />
          {joinError && <p className="mt-3 text-sm text-red-300">{joinError}</p>}
          <button
            type="button"
            disabled={busy}
            onClick={() => void join(name)}
            className="mt-4 w-full rounded-xl bg-gradient-to-r from-fuchsia-600 to-indigo-600 px-4 py-3 font-black uppercase shadow-lg transition hover:brightness-110 disabled:opacity-60"
          >
            Присоединиться
          </button>
          <button type="button" onClick={() => router.push("/")} className="mt-3 text-sm font-semibold text-white/50 hover:text-white">
            На главную
          </button>
        </div>
      </Centered>
    );
  }

  return (
    <>
      {view.phase === "lobby" || !view.game ? (
        <Lobby view={view} act={act} busy={busy} onLeave={leave} />
      ) : (
        <GameTable view={view} act={act} busy={busy} banner={banner} lastCard={lastCard} onLeave={leave} />
      )}
      {toast && (
        <div className="anim-pop fixed bottom-24 left-1/2 z-[100] max-w-[92vw] -translate-x-1/2 rounded-xl border border-red-300/40 bg-red-600/90 px-4 py-2 text-sm font-bold shadow-2xl">
          {toast}
        </div>
      )}
    </>
  );
}
