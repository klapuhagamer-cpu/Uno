"use client";

import { useEffect, useRef, useState } from "react";
import { audio } from "@/lib/client/audio";

export default function SoundControls() {
  const [open, setOpen] = useState(false);
  const [prefs, setPrefs] = useState({ muted: false, music: 0.6, sfx: 0.8 });
  const [previewing, setPreviewing] = useState(false);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    // настройки лежат в localStorage — читаем после загрузки страницы
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setPrefs(audio.getPrefs());
    return () => {
      if (timer.current) clearTimeout(timer.current);
    };
  }, []);

  const update = (patch: Partial<typeof prefs>) => {
    audio.unlock();
    audio.setPrefs(patch);
    setPrefs((p) => ({ ...p, ...patch }));
  };

  const preview = () => {
    audio.unlock();
    if (previewing) {
      audio.stopTension();
      if (timer.current) clearTimeout(timer.current);
      setPreviewing(false);
      return;
    }
    if (audio.tensionActive) return; // уже играет по-настоящему
    audio.startTension();
    setPreviewing(true);
    timer.current = setTimeout(() => {
      audio.stopTension();
      setPreviewing(false);
    }, 12000);
  };

  return (
    <div className="relative">
      <button
        type="button"
        onClick={() => {
          audio.unlock();
          setOpen((v) => !v);
        }}
        className="glass flex h-10 w-10 items-center justify-center rounded-full text-lg transition hover:bg-white/15"
        aria-label="Звук"
        title="Звук и музыка"
      >
        {prefs.muted ? "🔇" : "🔊"}
      </button>
      {open && (
        <div className="glass anim-pop absolute right-0 top-12 z-[80] w-72 rounded-2xl p-4 shadow-2xl">
          <label className="flex items-center justify-between text-sm font-semibold">
            Звук включён
            <input
              type="checkbox"
              checked={!prefs.muted}
              onChange={(e) => update({ muted: !e.target.checked })}
              className="h-5 w-5 accent-fuchsia-500"
            />
          </label>
          <label className="mt-3 block text-xs uppercase tracking-wider text-white/60">
            Музыка: {Math.round(prefs.music * 100)}%
            <input
              type="range"
              min={0}
              max={1}
              step={0.05}
              value={prefs.music}
              onChange={(e) => update({ music: Number(e.target.value) })}
              className="mt-1 w-full accent-fuchsia-500"
            />
          </label>
          <label className="mt-3 block text-xs uppercase tracking-wider text-white/60">
            Эффекты: {Math.round(prefs.sfx * 100)}%
            <input
              type="range"
              min={0}
              max={1}
              step={0.05}
              value={prefs.sfx}
              onChange={(e) => update({ sfx: Number(e.target.value) })}
              className="mt-1 w-full accent-fuchsia-500"
            />
          </label>
          <button
            type="button"
            onClick={preview}
            className="mt-4 w-full rounded-xl bg-gradient-to-r from-red-500 to-fuchsia-600 px-3 py-2 text-sm font-bold shadow-lg transition hover:brightness-110"
          >
            {previewing ? "■ Остановить" : "▶ Музыка «последняя карта»"}
          </button>
          <p className="mt-2 text-[11px] leading-snug text-white/50">
            Свой трек: положите файл <b>public/audio/last-card.mp3</b> — он заменит заглушку.
          </p>
        </div>
      )}
    </div>
  );
}
