import type { CSSProperties } from "react";
import type { Card, CardColor, CardValue, Color } from "@/lib/uno/types";

export const COLOR_HEX: Record<Color, string> = {
  red: "#ef3340",
  yellow: "#facc15",
  green: "#22b35e",
  blue: "#2f6bff",
};

export const COLOR_NAME: Record<Color, string> = {
  red: "Красный",
  yellow: "Жёлтый",
  green: "Зелёный",
  blue: "Синий",
};

const PALETTE: Record<CardColor, { bg: string; fg: string }> = {
  red: { bg: "linear-gradient(155deg,#ff6b6b 0%,#e11d36 60%,#a50f26 100%)", fg: "#d3162f" },
  yellow: { bg: "linear-gradient(155deg,#ffe97a 0%,#f7c20a 60%,#d79a00 100%)", fg: "#d89a00" },
  green: { bg: "linear-gradient(155deg,#5fe08f 0%,#1fa653 60%,#0f7a3a 100%)", fg: "#16954a" },
  blue: { bg: "linear-gradient(155deg,#6fb0ff 0%,#2563eb 60%,#1840a8 100%)", fg: "#1d56d6" },
  wild: { bg: "linear-gradient(155deg,#34343f 0%,#14141b 60%,#050508 100%)", fg: "#ffffff" },
};

const WILD_CONIC = "conic-gradient(#ef3340 0 25%, #facc15 0 50%, #22b35e 0 75%, #2f6bff 0 100%)";

function Icon({ value, size, color }: { value: CardValue; size: number; color: string }) {
  const common = {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: color,
    strokeWidth: 3,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
  };
  if (value === "skip") {
    return (
      <svg {...common}>
        <circle cx="12" cy="12" r="8.5" />
        <line x1="6" y1="18" x2="18" y2="6" />
      </svg>
    );
  }
  return (
    <svg {...common} strokeWidth={2.8}>
      <path d="M4 8h12M13 4l4 4-4 4" />
      <path d="M20 16H8M11 12l-4 4 4 4" />
    </svg>
  );
}

function Symbol({ card, size, color }: { card: Card; size: number; color: string }) {
  const v = card.value;
  if (v === "skip" || v === "reverse") return <Icon value={v} size={size * 1.05} color={color} />;
  const text = v === "draw2" ? "+2" : v === "wild4" ? "+4" : v === "wild" ? "" : v;
  return (
    <span
      style={{
        fontSize: size,
        lineHeight: 1,
        fontWeight: 900,
        color,
        letterSpacing: "-0.04em",
        textDecoration: v === "6" || v === "9" ? "underline" : undefined,
        textUnderlineOffset: size * 0.06,
      }}
    >
      {text}
    </span>
  );
}

interface UnoCardProps {
  card: Card;
  w?: number;
  playable?: boolean;
  dim?: boolean;
  glow?: boolean;
  className?: string;
  style?: CSSProperties;
  onClick?: () => void;
  title?: string;
}

export function UnoCard({ card, w = 80, playable, dim, glow, className = "", style, onClick, title }: UnoCardProps) {
  const pal = PALETTE[card.color];
  const isWild = card.color === "wild";
  const h = w * 1.5;
  const centerColor = isWild ? "#ffffff" : pal.fg;
  const centerSize = w * (card.value === "draw2" || card.value === "wild4" ? 0.42 : 0.5);
  const cornerSize = w * 0.19;

  return (
    <div
      role={onClick ? "button" : undefined}
      title={title}
      onClick={onClick}
      className={`card-hover relative shrink-0 select-none overflow-hidden ${playable ? "card-playable" : ""} ${dim ? "card-dim" : ""} ${className}`}
      style={{
        width: w,
        height: h,
        borderRadius: w * 0.12,
        background: pal.bg,
        border: `${Math.max(2, w * 0.045)}px solid #fbfbff`,
        boxShadow: glow
          ? "0 0 40px 8px rgba(255,255,255,0.35), 0 10px 24px rgba(0,0,0,0.55)"
          : "0 6px 14px rgba(0,0,0,0.45)",
        ...style,
      }}
    >
      {/* наклонный овал */}
      <div
        style={{
          position: "absolute",
          left: "-14%",
          right: "-14%",
          top: "13%",
          bottom: "13%",
          borderRadius: "50%",
          transform: "rotate(-26deg)",
          background: isWild ? WILD_CONIC : "#fdfdff",
          boxShadow: "inset 0 0 10px rgba(0,0,0,0.25)",
        }}
      />
      {/* символ по центру */}
      <div className="absolute inset-0 flex items-center justify-center" style={{ textShadow: isWild ? "0 2px 4px rgba(0,0,0,0.7)" : "0 2px 0 rgba(0,0,0,0.12)" }}>
        <Symbol card={card} size={centerSize} color={centerColor} />
      </div>
      {/* углы */}
      <div className="absolute flex items-center justify-center" style={{ left: w * 0.07, top: w * 0.05, color: "#fff" }}>
        {card.value === "wild" ? (
          <span style={{ width: cornerSize, height: cornerSize, borderRadius: "50%", background: WILD_CONIC, border: "1px solid #fff" }} />
        ) : (
          <Symbol card={card} size={cornerSize} color="#fff" />
        )}
      </div>
      <div
        className="absolute flex items-center justify-center"
        style={{ right: w * 0.07, bottom: w * 0.05, color: "#fff", transform: "rotate(180deg)" }}
      >
        {card.value === "wild" ? (
          <span style={{ width: cornerSize, height: cornerSize, borderRadius: "50%", background: WILD_CONIC, border: "1px solid #fff" }} />
        ) : (
          <Symbol card={card} size={cornerSize} color="#fff" />
        )}
      </div>
      {/* блик */}
      <div
        className="pointer-events-none absolute inset-0"
        style={{ background: "linear-gradient(120deg, rgba(255,255,255,0.28) 0%, rgba(255,255,255,0) 38%)" }}
      />
    </div>
  );
}

export function CardBack({ w = 60, className = "", style, onClick, glow }: { w?: number; className?: string; style?: CSSProperties; onClick?: () => void; glow?: boolean }) {
  const h = w * 1.5;
  return (
    <div
      role={onClick ? "button" : undefined}
      onClick={onClick}
      className={`card-hover relative shrink-0 select-none overflow-hidden ${className}`}
      style={{
        width: w,
        height: h,
        borderRadius: w * 0.12,
        background: "linear-gradient(155deg,#2a2a36 0%,#12121a 60%,#050508 100%)",
        border: `${Math.max(2, w * 0.045)}px solid #fbfbff`,
        boxShadow: glow
          ? "0 0 0 2px rgba(250,250,120,.95), 0 0 26px 6px rgba(250,230,90,.7), 0 8px 18px rgba(0,0,0,.5)"
          : "0 6px 14px rgba(0,0,0,0.45)",
        ...style,
      }}
    >
      <div
        style={{
          position: "absolute",
          left: "-14%",
          right: "-14%",
          top: "16%",
          bottom: "16%",
          borderRadius: "50%",
          transform: "rotate(-26deg)",
          background: "linear-gradient(160deg,#ff5a5f,#d7192f 70%,#8f0c20)",
          boxShadow: "inset 0 0 12px rgba(0,0,0,0.4)",
        }}
      />
      <div className="absolute inset-0 flex items-center justify-center">
        <span
          style={{
            fontSize: w * 0.34,
            fontWeight: 900,
            fontStyle: "italic",
            letterSpacing: "-0.03em",
            color: "#ffe14a",
            transform: "rotate(-26deg)",
            textShadow: "2px 2px 0 #12121a, -1px -1px 0 #12121a, 1px -1px 0 #12121a, -1px 1px 0 #12121a",
          }}
        >
          UNO
        </span>
      </div>
      <div
        className="pointer-events-none absolute inset-0"
        style={{ background: "linear-gradient(120deg, rgba(255,255,255,0.2) 0%, rgba(255,255,255,0) 38%)" }}
      />
    </div>
  );
}
