"use client";

import { useEffect, useRef, useState } from "react";
import { audio } from "@/lib/client/audio";
import type { RoomView } from "@/lib/uno/types";

/** Браузеры разрешают звук только после клика — "будим" аудио при первом жесте */
export function useAudioUnlock() {
  useEffect(() => {
    audio.load();
    const unlock = () => audio.unlock();
    window.addEventListener("pointerdown", unlock);
    window.addEventListener("keydown", unlock);
    return () => {
      window.removeEventListener("pointerdown", unlock);
      window.removeEventListener("keydown", unlock);
    };
  }, []);
}

export interface Banner {
  id: number;
  name: string;
}

/**
 * Звуки и эффекты, привязанные к событиям игры:
 *  - звуки ходов, штрафов, победы;
 *  - баннер "УНО!";
 *  - МУЗЫКА, пока у кого-то в руке одна карта.
 */
export function useGameFx(view: RoomView | null) {
  const lastEvent = useRef<number | null>(null);
  const lastTurn = useRef<number>(-1);
  const [banner, setBanner] = useState<Banner | null>(null);

  const youSeat = view?.youSeat ?? null;
  const events = view?.events;
  const seats = view?.seats;
  const turnSeq = view?.game?.turnSeq ?? -1;
  const current = view?.game?.current ?? -1;
  const phase = view?.phase;

  useEffect(() => {
    if (!events || !seats) return;
    const maxId = events.reduce((m, e) => Math.max(m, e.id), 0);
    if (lastEvent.current === null) {
      lastEvent.current = maxId; // историю при заходе не проигрываем
      return;
    }
    const fresh = events.filter((e) => e.id > (lastEvent.current ?? 0));
    lastEvent.current = Math.max(lastEvent.current, maxId);
    for (const e of fresh) {
      switch (e.type) {
        case "play":
          audio.sfx("play");
          break;
        case "draw":
          audio.sfx("draw");
          break;
        case "skip":
          audio.sfx("skip");
          break;
        case "reverse":
          audio.sfx("reverse");
          break;
        case "penalty":
          audio.sfx("penalty");
          break;
        case "start":
          audio.sfx("start");
          break;
        case "uno":
          audio.sfx("uno");
          setBanner({ id: e.id, name: e.seat !== null ? (seats[e.seat]?.name ?? "") : "" });
          break;
        case "win": {
          const winnerTeam = e.seat !== null ? seats[e.seat]?.team : null;
          const mine = youSeat !== null ? seats[youSeat] : null;
          const ours = e.seat !== null && mine !== null && (e.seat === youSeat || (winnerTeam !== null && winnerTeam === mine.team));
          audio.sfx(ours ? "win" : "penalty");
          break;
        }
        default:
          break;
      }
    }
  }, [events, seats, youSeat]);

  // сигнал "ваш ход"
  useEffect(() => {
    if (phase !== "playing" || turnSeq < 0) return;
    if (lastTurn.current !== turnSeq) {
      lastTurn.current = turnSeq;
      if (current === youSeat) audio.sfx("turn");
    }
  }, [phase, turnSeq, current, youSeat]);

  // Музыка: у кого-то осталась ровно одна карта
  const lastCard = phase === "playing" && !!seats && seats.some((s) => s.cardCount === 1);
  useEffect(() => {
    if (lastCard) audio.startTension();
    else audio.stopTension();
  }, [lastCard]);

  useEffect(() => () => audio.stopTension(), []);

  return { banner, lastCard };
}
