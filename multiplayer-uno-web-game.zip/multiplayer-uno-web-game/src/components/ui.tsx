import type { ReactNode } from "react";
import type { SeatKind } from "@/lib/uno/types";

export const TEAM_STYLE = [
  {
    label: "Команда A",
    short: "A",
    panel: "from-cyan-500/25 to-sky-700/15 border-cyan-400/50",
    chip: "bg-cyan-400 text-cyan-950",
    text: "text-cyan-300",
    ring: "#22d3ee",
  },
  {
    label: "Команда B",
    short: "B",
    panel: "from-pink-500/25 to-rose-700/15 border-pink-400/50",
    chip: "bg-pink-400 text-pink-950",
    text: "text-pink-300",
    ring: "#f472b6",
  },
];

function hash(s: string): number {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0;
  return h;
}

export function Avatar({
  name,
  kind,
  size = 48,
  ringColor,
  className = "",
}: {
  name: string;
  kind: SeatKind;
  size?: number;
  ringColor?: string;
  className?: string;
}) {
  const hue = hash(name) % 360;
  const bg =
    kind === "open"
      ? "rgba(255,255,255,0.08)"
      : kind === "bot"
        ? `linear-gradient(135deg, hsl(${hue} 25% 45%), hsl(${(hue + 40) % 360} 30% 28%))`
        : `linear-gradient(135deg, hsl(${hue} 85% 62%), hsl(${(hue + 55) % 360} 85% 45%))`;
  const content = kind === "bot" ? "🤖" : kind === "open" ? "＋" : (name.trim()[0] ?? "?").toUpperCase();
  return (
    <div
      className={`flex shrink-0 items-center justify-center rounded-full font-black text-white ${className}`}
      style={{
        width: size,
        height: size,
        fontSize: size * 0.46,
        background: bg,
        border: kind === "open" ? "2px dashed rgba(255,255,255,0.3)" : `3px solid ${ringColor ?? "rgba(255,255,255,0.85)"}`,
        textShadow: "0 2px 4px rgba(0,0,0,0.4)",
      }}
    >
      {content}
    </div>
  );
}

export function Segmented<T extends string | number>({
  value,
  options,
  onChange,
  disabled,
}: {
  value: T;
  options: { value: T; label: ReactNode }[];
  onChange: (v: T) => void;
  disabled?: boolean;
}) {
  return (
    <div className="flex rounded-xl bg-black/30 p-1">
      {options.map((o) => (
        <button
          key={String(o.value)}
          type="button"
          disabled={disabled}
          onClick={() => onChange(o.value)}
          className={`flex-1 rounded-lg px-3 py-2 text-sm font-bold transition ${
            o.value === value
              ? "bg-gradient-to-r from-fuchsia-600 to-indigo-600 text-white shadow"
              : "text-white/60 hover:bg-white/10 hover:text-white"
          } ${disabled ? "cursor-not-allowed opacity-70" : ""}`}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}
