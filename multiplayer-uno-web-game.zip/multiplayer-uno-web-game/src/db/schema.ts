import { bigint, integer, jsonb, pgTable, text, timestamp } from "drizzle-orm/pg-core";
import type { RoomState } from "@/lib/uno/types";

/**
 * Одна строка = одна комната UNO.
 * Всё состояние (места, колода, руки игроков, события) лежит в JSONB-колонке `state`.
 * Клиентам состояние отдаётся только через "view" (см. src/lib/uno/room.ts),
 * поэтому чужие карты наружу никогда не попадают.
 */
export const rooms = pgTable("uno_rooms", {
  code: text("code").primaryKey(),
  version: integer("version").notNull().default(0),
  state: jsonb("state").$type<RoomState>().notNull(),
  touchedAt: bigint("touched_at", { mode: "number" }).notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});
