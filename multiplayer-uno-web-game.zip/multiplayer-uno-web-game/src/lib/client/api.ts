import type { ClientAction, RoomView } from "@/lib/uno/types";

export class ApiError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.status = status;
  }
}

async function parse(res: Response): Promise<Record<string, unknown>> {
  try {
    return (await res.json()) as Record<string, unknown>;
  } catch {
    return {};
  }
}

export async function createRoomRequest(name: string, playerId: string): Promise<string> {
  const res = await fetch("/api/rooms", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name, playerId }),
  });
  const data = await parse(res);
  if (!res.ok || typeof data.code !== "string") {
    throw new ApiError(typeof data.error === "string" ? data.error : "Не удалось создать комнату", res.status);
  }
  return data.code;
}

export async function fetchRoomView(code: string, playerId: string): Promise<RoomView> {
  const res = await fetch(`/api/rooms/${encodeURIComponent(code)}?playerId=${encodeURIComponent(playerId)}`, {
    cache: "no-store",
  });
  const data = await parse(res);
  if (!res.ok) {
    throw new ApiError(typeof data.error === "string" ? data.error : "Ошибка соединения", res.status);
  }
  return data as unknown as RoomView;
}

export async function sendAction(
  code: string,
  playerId: string,
  action: ClientAction,
): Promise<RoomView | null> {
  const res = await fetch(`/api/rooms/${encodeURIComponent(code)}/action`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ playerId, action }),
  });
  const data = await parse(res);
  if (!res.ok) {
    throw new ApiError(typeof data.error === "string" ? data.error : "Ошибка соединения", res.status);
  }
  return (data.view as RoomView | null) ?? null;
}
