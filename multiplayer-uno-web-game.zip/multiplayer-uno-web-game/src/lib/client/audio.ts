/**
 * Звуковой движок игры. Всё синтезируется прямо в браузере (Web Audio API),
 * поэтому никаких аудиофайлов для работы не нужно.
 *
 * ЗАМЕНА МУЗЫКИ: положите свой трек в  public/audio/last-card.mp3  (или .ogg / .wav) —
 * и он автоматически заиграет вместо синтезированной заглушки, когда у кого-то
 * в руке останется одна карта.
 */

export type Sfx = "play" | "draw" | "skip" | "reverse" | "penalty" | "uno" | "win" | "turn" | "start" | "click";

interface Prefs {
  muted: boolean;
  music: number;
  sfx: number;
}

const PREFS_KEY = "uno.sound";
const CUSTOM_TRACKS = ["/audio/last-card.mp3", "/audio/last-card.ogg", "/audio/last-card.wav"];

const BPM = 144;
const STEP = 60 / BPM / 2; // восьмая нота

// Am – F – G – E : тревожная "эпичная" последовательность
const PROGRESSION = [
  { root: 45, notes: [57, 60, 64, 69] },
  { root: 41, notes: [53, 57, 60, 65] },
  { root: 43, notes: [55, 59, 62, 67] },
  { root: 40, notes: [52, 56, 59, 64] },
];
const ARP_PATTERN = [0, 1, 2, 3, 2, 3, 2, 1];

const midi = (m: number) => 440 * Math.pow(2, (m - 69) / 12);

interface ToneOpts {
  type?: OscillatorType;
  vol?: number;
  slideTo?: number;
  attack?: number;
  lp?: number;
  dest?: AudioNode;
}

interface TensionSession {
  bus: GainNode;
  lead: GainNode;
  delay: DelayNode;
  feedback: GainNode;
  wet: GainNode;
  timer: ReturnType<typeof setInterval>;
  step: number;
  next: number;
}

class AudioEngine {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private musicGain: GainNode | null = null;
  private sfxGain: GainNode | null = null;
  private noiseBuffer: AudioBuffer | null = null;
  private prefs: Prefs = { muted: false, music: 0.6, sfx: 0.8 };
  private loaded = false;

  private tensionWanted = false;
  private tensionToken = 0;
  private session: TensionSession | null = null;
  private custom: HTMLAudioElement | null = null;
  private customUrl: string | null | undefined; // undefined = ещё не проверяли, null = файла нет
  private fadeTimer: ReturnType<typeof setInterval> | null = null;

  /* ----- настройки ----- */

  load() {
    if (this.loaded || typeof window === "undefined") return;
    this.loaded = true;
    try {
      const raw = localStorage.getItem(PREFS_KEY);
      if (raw) this.prefs = { ...this.prefs, ...(JSON.parse(raw) as Partial<Prefs>) };
    } catch {
      /* ignore */
    }
  }

  getPrefs(): Prefs {
    this.load();
    return { ...this.prefs };
  }

  setPrefs(patch: Partial<Prefs>) {
    this.load();
    this.prefs = { ...this.prefs, ...patch };
    try {
      localStorage.setItem(PREFS_KEY, JSON.stringify(this.prefs));
    } catch {
      /* ignore */
    }
    this.applyVolumes();
  }

  private applyVolumes() {
    if (this.master) this.master.gain.value = this.prefs.muted ? 0 : 1;
    if (this.musicGain) this.musicGain.gain.value = this.prefs.music;
    if (this.sfxGain) this.sfxGain.gain.value = this.prefs.sfx;
    if (this.custom) this.custom.volume = this.prefs.muted ? 0 : Math.min(1, this.prefs.music);
  }

  /* ----- инициализация (нужен жест пользователя) ----- */

  unlock() {
    this.load();
    if (typeof window === "undefined") return;
    if (!this.ctx) {
      const Ctor =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!Ctor) return;
      this.ctx = new Ctor();
      this.master = this.ctx.createGain();
      this.musicGain = this.ctx.createGain();
      this.sfxGain = this.ctx.createGain();
      this.musicGain.connect(this.master);
      this.sfxGain.connect(this.master);
      this.master.connect(this.ctx.destination);

      const len = this.ctx.sampleRate * 1.5;
      this.noiseBuffer = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
      const data = this.noiseBuffer.getChannelData(0);
      for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
      this.applyVolumes();
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
    if (this.tensionWanted && !this.session && !this.custom) void this.beginTension();
  }

  /* ----- примитивы ----- */

  private tone(freq: number, t: number, dur: number, o: ToneOpts = {}) {
    const ctx = this.ctx;
    if (!ctx) return;
    const { type = "sine", vol = 0.2, slideTo, attack = 0.005, lp, dest } = o;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, t);
    if (slideTo) osc.frequency.exponentialRampToValueAtTime(slideTo, t + dur);
    gain.gain.setValueAtTime(0.0001, t);
    gain.gain.exponentialRampToValueAtTime(Math.max(vol, 0.0002), t + attack);
    gain.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    let node: AudioNode = osc;
    if (lp) {
      const f = ctx.createBiquadFilter();
      f.type = "lowpass";
      f.frequency.value = lp;
      osc.connect(f);
      node = f;
    }
    node.connect(gain);
    gain.connect(dest ?? this.sfxGain!);
    osc.start(t);
    osc.stop(t + dur + 0.05);
  }

  private noise(
    t: number,
    dur: number,
    opts: { type?: BiquadFilterType; freq?: number; endFreq?: number; vol?: number; dest?: AudioNode; q?: number } = {},
  ) {
    const ctx = this.ctx;
    if (!ctx || !this.noiseBuffer) return;
    const { type = "bandpass", freq = 2000, endFreq, vol = 0.2, dest, q = 1 } = opts;
    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuffer;
    const filter = ctx.createBiquadFilter();
    filter.type = type;
    filter.Q.value = q;
    filter.frequency.setValueAtTime(freq, t);
    if (endFreq) filter.frequency.exponentialRampToValueAtTime(endFreq, t + dur);
    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.0001, t);
    gain.gain.exponentialRampToValueAtTime(Math.max(vol, 0.0002), t + Math.min(0.01, dur / 3));
    gain.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(filter);
    filter.connect(gain);
    gain.connect(dest ?? this.sfxGain!);
    src.start(t, Math.random());
    src.stop(t + dur + 0.05);
  }

  /* ----- эффекты ----- */

  sfx(kind: Sfx) {
    this.load();
    if (this.prefs.muted) return;
    const ctx = this.ctx;
    if (!ctx) return;
    const t = ctx.currentTime + 0.01;
    switch (kind) {
      case "play":
        this.noise(t, 0.09, { freq: 1800, vol: 0.35, q: 0.8 });
        this.tone(240, t, 0.12, { type: "triangle", vol: 0.25, slideTo: 110 });
        break;
      case "draw":
        this.noise(t, 0.16, { type: "highpass", freq: 900, endFreq: 5000, vol: 0.22 });
        this.tone(520, t + 0.1, 0.05, { type: "square", vol: 0.05 });
        break;
      case "skip":
        this.tone(480, t, 0.12, { type: "square", vol: 0.12, lp: 1800 });
        this.tone(320, t + 0.13, 0.2, { type: "square", vol: 0.12, lp: 1800 });
        break;
      case "reverse":
        this.tone(300, t, 0.22, { type: "sine", vol: 0.25, slideTo: 900 });
        this.tone(900, t + 0.22, 0.22, { type: "sine", vol: 0.25, slideTo: 300 });
        break;
      case "penalty":
        this.tone(130, t, 0.5, { type: "sawtooth", vol: 0.3, slideTo: 45, lp: 600 });
        this.noise(t, 0.3, { type: "lowpass", freq: 800, vol: 0.3 });
        break;
      case "turn":
        this.tone(880, t, 0.35, { type: "sine", vol: 0.14 });
        this.tone(1320, t + 0.08, 0.4, { type: "sine", vol: 0.1 });
        break;
      case "start":
        this.tone(110, t, 0.9, { type: "sawtooth", vol: 0.2, slideTo: 440, lp: 1500, attack: 0.3 });
        this.noise(t, 0.9, { type: "highpass", freq: 400, endFreq: 6000, vol: 0.2 });
        this.tone(660, t + 0.9, 0.5, { type: "triangle", vol: 0.2 });
        break;
      case "click":
        this.tone(700, t, 0.04, { type: "triangle", vol: 0.1 });
        break;
      case "uno": {
        [57, 60, 64, 69].forEach((m, i) =>
          this.tone(midi(m), t + i * 0.09, 0.5, { type: "sawtooth", vol: 0.16, lp: 2600 }),
        );
        this.tone(midi(33), t, 0.9, { type: "sawtooth", vol: 0.3, lp: 300 });
        this.noise(t + 0.3, 0.6, { type: "highpass", freq: 600, endFreq: 7000, vol: 0.12 });
        this.speak("Уно!");
        break;
      }
      case "win": {
        const seq = [72, 76, 79, 84, 79, 84, 88];
        seq.forEach((m, i) => {
          this.tone(midi(m), t + i * 0.12, 0.45, { type: "triangle", vol: 0.25 });
          this.tone(midi(m - 12), t + i * 0.12, 0.45, { type: "sawtooth", vol: 0.07, lp: 1500 });
        });
        [60, 64, 67, 72].forEach((m) =>
          this.tone(midi(m), t + seq.length * 0.12, 1.6, { type: "sawtooth", vol: 0.1, lp: 2200, attack: 0.02 }),
        );
        break;
      }
    }
  }

  private speak(text: string) {
    try {
      if (typeof speechSynthesis === "undefined") return;
      const u = new SpeechSynthesisUtterance(text);
      u.lang = "ru-RU";
      u.pitch = 0.6;
      u.rate = 1.05;
      u.volume = Math.min(1, this.prefs.sfx);
      speechSynthesis.cancel();
      speechSynthesis.speak(u);
    } catch {
      /* озвучка необязательна */
    }
  }

  /* ----- музыка "осталась одна карта" ----- */

  get tensionActive(): boolean {
    return this.tensionWanted;
  }

  startTension() {
    if (this.tensionWanted) return;
    this.tensionWanted = true;
    if (this.ctx) void this.beginTension();
  }

  stopTension() {
    if (!this.tensionWanted) return;
    this.tensionWanted = false;
    this.tensionToken += 1;
    this.endSynth();
    this.endCustom();
  }

  private async findCustom(): Promise<string | null> {
    if (this.customUrl !== undefined) return this.customUrl;
    for (const url of CUSTOM_TRACKS) {
      try {
        const res = await fetch(url, { method: "HEAD", cache: "no-store" });
        const type = res.headers.get("content-type") ?? "";
        if (res.ok && (type.startsWith("audio") || type.includes("ogg") || type.includes("octet"))) {
          this.customUrl = url;
          return url;
        }
      } catch {
        /* пробуем следующий */
      }
    }
    this.customUrl = null;
    return null;
  }

  private async beginTension() {
    const token = ++this.tensionToken;
    const url = await this.findCustom();
    if (token !== this.tensionToken || !this.tensionWanted) return;
    if (url) {
      this.startCustom(url);
    } else {
      this.startSynth();
    }
  }

  private startCustom(url: string) {
    if (this.custom) return;
    if (this.fadeTimer) clearInterval(this.fadeTimer);
    const el = new Audio(url);
    el.loop = true;
    el.volume = this.prefs.muted ? 0 : Math.min(1, this.prefs.music);
    this.custom = el;
    el.play().catch(() => {
      this.custom = null;
      this.startSynth();
    });
  }

  private endCustom() {
    const el = this.custom;
    if (!el) return;
    this.custom = null;
    if (this.fadeTimer) clearInterval(this.fadeTimer);
    const startVol = el.volume;
    let n = 0;
    this.fadeTimer = setInterval(() => {
      n += 1;
      el.volume = Math.max(0, startVol * (1 - n / 8));
      if (n >= 8) {
        el.pause();
        if (this.fadeTimer) clearInterval(this.fadeTimer);
        this.fadeTimer = null;
      }
    }, 50);
  }

  private startSynth() {
    const ctx = this.ctx;
    if (!ctx || !this.musicGain || this.session) return;
    const bus = ctx.createGain();
    bus.gain.value = 0.0001;
    bus.gain.exponentialRampToValueAtTime(1, ctx.currentTime + 0.6);
    bus.connect(this.musicGain);

    const lead = ctx.createGain();
    const delay = ctx.createDelay(1);
    delay.delayTime.value = STEP * 1.5;
    const feedback = ctx.createGain();
    feedback.gain.value = 0.38;
    const wet = ctx.createGain();
    wet.gain.value = 0.45;
    lead.connect(bus);
    lead.connect(delay);
    delay.connect(feedback);
    feedback.connect(delay);
    delay.connect(wet);
    wet.connect(bus);

    const session: TensionSession = {
      bus,
      lead,
      delay,
      feedback,
      wet,
      step: 0,
      next: ctx.currentTime + 0.08,
      timer: setInterval(() => this.pump(session), 25),
    };
    this.session = session;
  }

  private endSynth() {
    const ctx = this.ctx;
    const s = this.session;
    if (!s || !ctx) return;
    this.session = null;
    clearInterval(s.timer);
    s.bus.gain.cancelScheduledValues(ctx.currentTime);
    s.bus.gain.setValueAtTime(Math.max(s.bus.gain.value, 0.0001), ctx.currentTime);
    s.bus.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.5);
    setTimeout(() => {
      try {
        s.bus.disconnect();
        s.lead.disconnect();
        s.delay.disconnect();
        s.feedback.disconnect();
        s.wet.disconnect();
      } catch {
        /* ignore */
      }
    }, 2500);
  }

  private pump(s: TensionSession) {
    const ctx = this.ctx;
    if (!ctx || this.session !== s) return;
    while (s.next < ctx.currentTime + 0.15) {
      this.scheduleStep(s, s.step, s.next);
      s.next += STEP;
      s.step += 1;
    }
  }

  private scheduleStep(s: TensionSession, stepIdx: number, t: number) {
    const bar = Math.floor(stepIdx / 8) % PROGRESSION.length;
    const st = stepIdx % 8;
    const chord = PROGRESSION[bar];
    const bus = s.bus;

    // бас
    const bassNote = chord.root + (st % 4 === 3 ? 12 : 0);
    this.tone(midi(bassNote), t, STEP * 0.95, { type: "sawtooth", vol: 0.26, lp: 420, dest: bus });

    // бочка (как сердцебиение)
    if (st % 2 === 0) {
      this.tone(150, t, 0.2, { type: "sine", vol: 0.9, slideTo: 42, attack: 0.002, dest: bus });
    }
    if (st === 7 && bar === 3) {
      this.tone(150, t, 0.2, { type: "sine", vol: 0.7, slideTo: 42, attack: 0.002, dest: bus });
    }
    // рабочий барабан
    if (st === 2 || st === 6) {
      this.noise(t, 0.16, { type: "bandpass", freq: 1900, vol: 0.4, q: 0.7, dest: bus });
      this.tone(200, t, 0.1, { type: "triangle", vol: 0.25, slideTo: 120, dest: bus });
    }
    // хет
    if (st % 2 === 1) {
      this.noise(t, 0.05, { type: "highpass", freq: 7500, vol: 0.14, dest: bus });
    }
    // арпеджио
    const arpNote = chord.notes[ARP_PATTERN[st]] + (st === 6 ? 12 : 0);
    this.tone(midi(arpNote), t, STEP * 1.1, { type: "sawtooth", vol: 0.075, lp: 2400, attack: 0.004, dest: s.lead });
    this.tone(midi(arpNote + 12), t, STEP * 0.6, { type: "square", vol: 0.025, lp: 3000, attack: 0.004, dest: s.lead });

    // педаль-аккорд
    if (st === 0) {
      chord.notes.slice(0, 3).forEach((m) =>
        this.tone(midi(m), t, STEP * 8, { type: "triangle", vol: 0.07, attack: 0.25, dest: bus }),
      );
      // нарастание в последнем такте
      if (bar === 3) {
        this.noise(t, STEP * 8, { type: "highpass", freq: 600, endFreq: 7000, vol: 0.16, dest: bus });
      }
    }
  }
}

export const audio = new AudioEngine();
