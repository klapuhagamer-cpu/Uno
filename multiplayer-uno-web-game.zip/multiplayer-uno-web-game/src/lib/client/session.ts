const ID_KEY = "uno.playerId";
const NAME_KEY = "uno.name";

function randomId(): string {
  try {
    if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") return crypto.randomUUID();
  } catch {
    /* небезопасный контекст (http по IP) — используем запасной вариант */
  }
  const bytes = new Uint8Array(16);
  if (typeof crypto !== "undefined" && crypto.getRandomValues) crypto.getRandomValues(bytes);
  else for (let i = 0; i < bytes.length; i++) bytes[i] = Math.floor(Math.random() * 256);
  return Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
}

/**
 * Идентификатор игрока хранится в sessionStorage: у каждой вкладки он свой.
 * Так можно открыть две вкладки и играть "за двоих" на одном компьютере.
 */
export function getPlayerId(): string {
  try {
    let id = sessionStorage.getItem(ID_KEY);
    if (!id) {
      id = randomId();
      sessionStorage.setItem(ID_KEY, id);
    }
    return id;
  } catch {
    return randomId();
  }
}

export function getSavedName(): string {
  try {
    return localStorage.getItem(NAME_KEY) ?? "";
  } catch {
    return "";
  }
}

export function saveName(name: string) {
  try {
    localStorage.setItem(NAME_KEY, name);
  } catch {
    /* ignore */
  }
}
