import { COLORS, cardPoints, isPlayable, teamOf } from "./engine";
import type { Card, Color, RoomState } from "./types";

export type BotMove =
  | { type: "play"; cardId: number; color?: Color }
  | { type: "draw" }
  | { type: "pass" };

function pick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

function colorCounts(hand: Card[]): Record<Color, number> {
  const counts: Record<Color, number> = { red: 0, yellow: 0, green: 0, blue: 0 };
  for (const c of hand) if (c.color !== "wild") counts[c.color] += 1;
  return counts;
}

/** Самый частый цвет в оставшейся руке (при равенстве — случайный) */
function bestColor(rest: Card[]): Color {
  const counts = colorCounts(rest);
  const max = Math.max(...COLORS.map((c) => counts[c]));
  if (max === 0) return pick(COLORS);
  return pick(COLORS.filter((c) => counts[c] === max));
}

function neighbor(room: RoomState, seat: number, dir: 1 | -1): number {
  const n = room.seats.length;
  return (((seat + dir) % n) + n) % n;
}

function scoreCard(room: RoomState, seat: number, card: Card, level: "normal" | "hard"): number {
  const g = room.game!;
  const hand = g.hands[seat];
  const rest = hand.filter((c) => c.id !== card.id);
  const counts = colorCounts(rest);
  let score = Math.random(); // небольшая случайность, чтобы боты не были предсказуемыми

  const isWild = card.color === "wild";
  const isAction = card.value === "skip" || card.value === "reverse" || card.value === "draw2";

  if (isWild) {
    // Дикие карты бережём, если есть чем ходить
    score -= card.value === "wild4" ? 35 : 30;
    if (hand.length <= 2) score += 60;
  } else {
    score += cardPoints(card) / 6;
    score += counts[card.color as Color] * 2;
    if (isAction) score += 3;
  }

  if (level === "hard") {
    const dir = g.direction;
    const next = neighbor(room, seat, dir);
    const prev = neighbor(room, seat, dir === 1 ? -1 : 1);
    const myTeam = teamOf(room, seat);
    const isFriend = (s: number) => myTeam !== null && teamOf(room, s) === myTeam;
    const nextCount = g.hands[next].length;
    const prevCount = g.hands[prev].length;

    if (!isFriend(next)) {
      const danger = nextCount <= 2 ? 1 : nextCount <= 4 ? 0.4 : 0;
      if (card.value === "draw2") score += 8 * danger;
      if (card.value === "wild4") score += 14 * danger;
      if (card.value === "skip") score += 9 * danger;
    } else if (card.value === "draw2" || card.value === "wild4" || card.value === "skip") {
      score -= 15; // не мешаем союзнику
    }
    if (card.value === "reverse" && room.seats.length > 2) {
      // разворот полезен, если следующий игрок ближе к победе, чем предыдущий
      if (nextCount < prevCount && !isFriend(next)) score += 6;
    }
    // Выходим из игры любой ценностью, когда осталась пара карт
    if (hand.length === 2) score += 12;
  }

  return score;
}

export function chooseBotMove(room: RoomState, seat: number): BotMove {
  const g = room.game!;
  const hand = g.hands[seat];
  const level = room.settings.botLevel;
  const playable = hand.filter((c) => isPlayable(room, c));

  if (playable.length === 0) {
    return g.drawn !== null ? { type: "pass" } : { type: "draw" };
  }

  // Лёгкий бот иногда сознательно берёт штраф вместо ответа
  if (level === "easy" && g.penalty > 0 && Math.random() < 0.3) return { type: "draw" };

  let chosen: Card;
  if (level === "easy") {
    chosen = pick(playable);
  } else {
    const scored = playable.map((c) => ({ c, s: scoreCard(room, seat, c, level) }));
    scored.sort((a, b) => b.s - a.s);
    chosen = scored[0].c;
  }

  if (chosen.color === "wild") {
    const rest = hand.filter((c) => c.id !== chosen.id);
    const color = level === "easy" ? pick(COLORS) : bestColor(rest);
    return { type: "play", cardId: chosen.id, color };
  }
  return { type: "play", cardId: chosen.id };
}
