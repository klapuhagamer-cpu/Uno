import type { Card, CardValue, Color, EventType, GameState, RoomState } from "./types";

export class GameError extends Error {}

export const COLORS: Color[] = ["red", "yellow", "green", "blue"];

export const COLOR_EMOJI: Record<Color, string> = {
  red: "🟥",
  yellow: "🟨",
  green: "🟩",
  blue: "🟦",
};

const SYMBOL_TEXT: Record<CardValue, string> = {
  "0": "0",
  "1": "1",
  "2": "2",
  "3": "3",
  "4": "4",
  "5": "5",
  "6": "6",
  "7": "7",
  "8": "8",
  "9": "9",
  skip: "Пропуск",
  reverse: "Разворот",
  draw2: "+2",
  wild: "Выбор цвета",
  wild4: "+4 и выбор цвета",
};

export function buildDeck(): Card[] {
  const cards: Card[] = [];
  let id = 0;
  for (const color of COLORS) {
    cards.push({ id: id++, color, value: "0" });
    for (let n = 1; n <= 9; n++) {
      for (let k = 0; k < 2; k++) cards.push({ id: id++, color, value: String(n) as CardValue });
    }
    for (const value of ["skip", "reverse", "draw2"] as const) {
      for (let k = 0; k < 2; k++) cards.push({ id: id++, color, value });
    }
  }
  for (let k = 0; k < 4; k++) {
    cards.push({ id: id++, color: "wild", value: "wild" });
    cards.push({ id: id++, color: "wild", value: "wild4" });
  }
  return cards;
}

export function shuffle<T>(input: T[]): T[] {
  const arr = input.slice();
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

export function cardText(card: Card): string {
  const symbol = SYMBOL_TEXT[card.value];
  return card.color === "wild" ? `⬛ ${symbol}` : `${COLOR_EMOJI[card.color]} ${symbol}`;
}

export function cardPoints(card: Card): number {
  if (card.value === "wild" || card.value === "wild4") return 50;
  if (card.value === "skip" || card.value === "reverse" || card.value === "draw2") return 20;
  return Number(card.value);
}

export function teamOf(room: RoomState, seat: number): number | null {
  return room.settings.mode === "teams" ? seat % 2 : null;
}

export function pushEvent(room: RoomState, type: EventType, seat: number | null, text: string) {
  room.eventSeq += 1;
  room.events.push({ id: room.eventSeq, type, seat, text });
  if (room.events.length > 14) room.events.splice(0, room.events.length - 14);
}

/** Нужно ли вызывающему коду что-то пересчитать после хода бота/игрока */
export function topCard(game: GameState): Card {
  return game.discard[game.discard.length - 1];
}

export function startGame(room: RoomState) {
  const n = room.seats.length;
  const deck = shuffle(buildDeck());
  const hands: Card[][] = Array.from({ length: n }, () => []);
  for (let round = 0; round < 7; round++) {
    for (let s = 0; s < n; s++) hands[s].push(deck.pop()!);
  }
  // Первая карта на столе — всегда обычная числовая
  let first = deck.pop()!;
  while (first.color === "wild" || ["skip", "reverse", "draw2"].includes(first.value)) {
    deck.unshift(first);
    first = deck.pop()!;
  }
  room.game = {
    hands,
    drawPile: deck,
    discard: [first],
    current: Math.floor(Math.random() * n),
    direction: 1,
    color: first.color as Color,
    penalty: 0,
    drawn: null,
    winner: null,
    winnerTeam: null,
    points: 0,
    turnSeq: 1,
  };
  room.phase = "playing";
  room.events = [];
  pushEvent(room, "start", null, `Игра началась! Первым ходит ${room.seats[room.game.current].name}`);
}

function nextSeat(game: GameState, n: number, from: number, steps = 1): number {
  return (((from + game.direction * steps) % n) + n) % n;
}

function advance(room: RoomState, steps = 1) {
  const g = room.game!;
  g.current = nextSeat(g, room.seats.length, g.current, steps);
  g.turnSeq += 1;
}

/** Берёт n карт из колоды (при необходимости перемешивает сброс) */
function drawCards(room: RoomState, seat: number, n: number): Card[] {
  const g = room.game!;
  const taken: Card[] = [];
  for (let i = 0; i < n; i++) {
    if (g.drawPile.length === 0) {
      const top = g.discard.pop()!;
      g.drawPile = shuffle(g.discard);
      g.discard = [top];
    }
    const card = g.drawPile.pop();
    if (!card) break;
    g.hands[seat].push(card);
    taken.push(card);
  }
  return taken;
}

export function isPlayable(room: RoomState, card: Card): boolean {
  const g = room.game!;
  const top = topCard(g);
  if (g.drawn !== null && card.id !== g.drawn) return false;
  if (g.penalty > 0) {
    return (card.value === "draw2" && top.value === "draw2") || card.value === "wild4";
  }
  if (card.color === "wild") return true;
  return card.color === g.color || card.value === top.value;
}

export function playableIds(room: RoomState, seat: number): number[] {
  const g = room.game;
  if (!g || room.phase !== "playing" || g.current !== seat) return [];
  return g.hands[seat].filter((c) => isPlayable(room, c)).map((c) => c.id);
}

function finish(room: RoomState, seat: number) {
  const g = room.game!;
  g.winner = seat;
  const winnerTeam = teamOf(room, seat);
  g.winnerTeam = winnerTeam;
  let points = 0;
  g.hands.forEach((hand, s) => {
    const isAlly = winnerTeam !== null ? teamOf(room, s) === winnerTeam : s === seat;
    if (!isAlly) points += hand.reduce((sum, c) => sum + cardPoints(c), 0);
  });
  g.points = points;
  room.phase = "finished";
  const name = room.seats[seat].name;
  if (winnerTeam !== null) {
    pushEvent(room, "win", seat, `Побеждает команда ${winnerTeam === 0 ? "A" : "B"}! ${name} сбросил последнюю карту`);
  } else {
    pushEvent(room, "win", seat, `${name} выигрывает партию!`);
  }
}

export function playCard(room: RoomState, seat: number, cardId: number, chosen?: Color) {
  const g = room.game;
  if (!g || room.phase !== "playing") throw new GameError("Игра не идёт");
  if (g.current !== seat) throw new GameError("Сейчас не ваш ход");
  const hand = g.hands[seat];
  const idx = hand.findIndex((c) => c.id === cardId);
  if (idx < 0) throw new GameError("Такой карты нет на руке");
  const card = hand[idx];
  if (!isPlayable(room, card)) throw new GameError("Эту карту сейчас нельзя сыграть");
  if (card.color === "wild" && (!chosen || !COLORS.includes(chosen))) {
    throw new GameError("Выберите цвет");
  }

  const n = room.seats.length;
  const name = room.seats[seat].name;

  hand.splice(idx, 1);
  g.discard.push(card);
  g.drawn = null;
  g.color = card.color === "wild" ? chosen! : card.color;

  pushEvent(
    room,
    "play",
    seat,
    card.color === "wild" ? `${name}: ${cardText(card)} → ${COLOR_EMOJI[g.color]}` : `${name}: ${cardText(card)}`,
  );

  if (hand.length === 0) {
    finish(room, seat);
    return;
  }
  if (hand.length === 1) {
    pushEvent(room, "uno", seat, `${name}: УНО! Осталась одна карта!`);
  }

  switch (card.value) {
    case "skip": {
      const victim = nextSeat(g, n, seat);
      pushEvent(room, "skip", victim, `${room.seats[victim].name} пропускает ход`);
      advance(room, 2);
      break;
    }
    case "reverse": {
      if (n === 2) {
        pushEvent(room, "skip", 1 - seat, `${room.seats[1 - seat].name} пропускает ход`);
        advance(room, 2);
      } else {
        g.direction = g.direction === 1 ? -1 : 1;
        pushEvent(room, "reverse", seat, "Порядок ходов изменился!");
        advance(room, 1);
      }
      break;
    }
    case "draw2":
    case "wild4": {
      const amount = card.value === "draw2" ? 2 : 4;
      if (room.settings.stacking) {
        g.penalty += amount;
        advance(room, 1);
        pushEvent(
          room,
          "penalty",
          g.current,
          `${room.seats[g.current].name} должен ответить или взять ${g.penalty} карт`,
        );
      } else {
        const victim = nextSeat(g, n, seat);
        drawCards(room, victim, amount);
        pushEvent(room, "penalty", victim, `${room.seats[victim].name} берёт ${amount} карты и пропускает ход`);
        advance(room, 2);
      }
      break;
    }
    default:
      advance(room, 1);
  }
}

export function drawAction(room: RoomState, seat: number) {
  const g = room.game;
  if (!g || room.phase !== "playing") throw new GameError("Игра не идёт");
  if (g.current !== seat) throw new GameError("Сейчас не ваш ход");
  if (g.drawn !== null) throw new GameError("Вы уже взяли карту: сыграйте её или пропустите ход");
  const name = room.seats[seat].name;

  if (g.penalty > 0) {
    const amount = g.penalty;
    drawCards(room, seat, amount);
    g.penalty = 0;
    pushEvent(room, "penalty", seat, `${name} берёт штраф: ${amount} карт`);
    advance(room, 1);
    return;
  }

  const [card] = drawCards(room, seat, 1);
  pushEvent(room, "draw", seat, `${name} берёт карту`);
  if (!card) {
    advance(room, 1);
    return;
  }
  if (isPlayable(room, card)) {
    g.drawn = card.id;
  } else {
    advance(room, 1);
  }
}

export function passAction(room: RoomState, seat: number) {
  const g = room.game;
  if (!g || room.phase !== "playing") throw new GameError("Игра не идёт");
  if (g.current !== seat) throw new GameError("Сейчас не ваш ход");
  if (g.drawn === null) throw new GameError("Сначала возьмите карту");
  g.drawn = null;
  pushEvent(room, "info", seat, `${room.seats[seat].name} пропускает ход`);
  advance(room, 1);
}
