import { chooseBotMove } from "./bot";
import {
  GameError,
  drawAction,
  isPlayable,
  passAction,
  playCard,
  playableIds,
  pushEvent,
  startGame,
  teamOf,
  topCard,
} from "./engine";
import type {
  BotLevel,
  Card,
  CardColor,
  ClientAction,
  Color,
  Mode,
  RoomState,
  RoomView,
  Seat,
} from "./types";

export const AWAY_MS = 45_000; // через это время без связи за игрока ходит бот
const AWAY_BADGE_MS = 15_000;
const MAX_SEATS = 6;

const BOT_NAMES = [
  "Робо-Макс",
  "Искра",
  "Чип",
  "Нова",
  "Гром",
  "Бублик",
  "Тень",
  "Кибер-Вася",
  "Молния",
  "Пиксель",
  "Зефир",
  "Турбо",
];

function pick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

export function cleanName(raw: string): string {
  return raw.replace(/\s+/g, " ").trim().slice(0, 16);
}

function botName(room: RoomState): string {
  const used = new Set(room.seats.map((s) => s.name));
  const free = BOT_NAMES.filter((n) => !used.has(n));
  return pick(free.length ? free : BOT_NAMES);
}

function makeBotSeat(room: RoomState): Seat {
  return { kind: "bot", name: botName(room), playerId: null, lastSeen: 0 };
}

function makeOpenSeat(): Seat {
  return { kind: "open", name: "Свободно", playerId: null, lastSeen: 0 };
}

function makeHumanSeat(playerId: string, name: string, now: number): Seat {
  return { kind: "human", name, playerId, lastSeen: now };
}

export function createRoomState(code: string, hostId: string, hostName: string, now: number): RoomState {
  const room: RoomState = {
    code,
    hostId,
    phase: "lobby",
    settings: { mode: "ffa", seatCount: 4, stacking: false, botLevel: "normal" },
    seats: [],
    game: null,
    events: [],
    eventSeq: 0,
    nextBotAt: 0,
  };
  room.seats.push(makeHumanSeat(hostId, cleanName(hostName) || "Хост", now));
  for (let i = 1; i < 4; i++) room.seats.push(makeBotSeat(room));
  return room;
}

export function findSeat(room: RoomState, playerId: string | null | undefined): number {
  if (!playerId) return -1;
  return room.seats.findIndex((s) => s.kind === "human" && s.playerId === playerId);
}

/* ---------------- Настройка мест ---------------- */

function resizeSeats(room: RoomState, n: number) {
  if (n > room.seats.length) {
    while (room.seats.length < n) room.seats.push(makeBotSeat(room));
  } else if (n < room.seats.length) {
    const kept = room.seats.slice(0, n);
    for (const s of room.seats.slice(n)) {
      if (s.kind !== "human") continue;
      const i = kept.findIndex((k) => k.kind !== "human");
      if (i < 0) throw new GameError("Слишком много игроков для такого числа мест");
      kept[i] = s;
    }
    room.seats = kept;
  }
  room.settings.seatCount = room.seats.length;
}

function clampSeats(n: number): number {
  return Math.max(2, Math.min(MAX_SEATS, Math.floor(n)));
}

function joinRoom(room: RoomState, playerId: string, rawName: string, now: number) {
  const name = cleanName(rawName);
  if (!name) throw new GameError("Введите ник");
  const existing = findSeat(room, playerId);
  if (existing >= 0) {
    room.seats[existing].lastSeen = now;
    return;
  }
  if (room.phase !== "lobby") throw new GameError("Игра уже идёт. Дождитесь окончания партии");
  let idx = room.seats.findIndex((s) => s.kind === "open");
  if (idx < 0) {
    for (let i = room.seats.length - 1; i >= 0; i--) {
      if (room.seats[i].kind === "bot") {
        idx = i;
        break;
      }
    }
  }
  if (idx < 0) throw new GameError("В комнате нет свободных мест");
  room.seats[idx] = makeHumanSeat(playerId, name, now);
}

/** Возвращает true, если в комнате не осталось людей (комнату можно удалять) */
function leaveRoom(room: RoomState, playerId: string): boolean {
  const idx = findSeat(room, playerId);
  if (idx < 0) return false;
  const seat = room.seats[idx];
  if (room.phase === "lobby") {
    room.seats[idx] = makeOpenSeat();
  } else {
    pushEvent(room, "info", idx, `${seat.name} покинул игру — вместо него играет бот`);
    room.seats[idx] = { kind: "bot", name: `${seat.name} (бот)`, playerId: null, lastSeen: 0 };
  }
  if (room.hostId === playerId) {
    const next = room.seats.find((s) => s.kind === "human");
    if (next?.playerId) room.hostId = next.playerId;
  }
  return !room.seats.some((s) => s.kind === "human");
}

export function scheduleBot(room: RoomState, now: number) {
  room.nextBotAt = now + 950 + Math.random() * 850;
}

function startFromLobby(room: RoomState, now: number) {
  if (room.settings.mode === "teams" && room.seats.length !== 4) {
    throw new GameError("Для командного режима нужно ровно 4 места");
  }
  if (room.seats.length < 2) throw new GameError("Нужно минимум 2 места");
  for (let i = 0; i < room.seats.length; i++) {
    if (room.seats[i].kind === "open") room.seats[i] = makeBotSeat(room);
  }
  startGame(room);
  scheduleBot(room, now);
}

/* ---------------- Действия игроков ---------------- */

export interface ActionOutcome {
  remove: boolean;
}

export function applyAction(room: RoomState, playerId: string, action: ClientAction, now: number): ActionOutcome {
  if (action.type === "join") {
    joinRoom(room, playerId, action.name, now);
    return { remove: false };
  }

  const me = findSeat(room, playerId);
  if (me < 0) throw new GameError("Вы не находитесь в этой комнате");
  room.seats[me].lastSeen = now;
  const isHost = room.hostId === playerId;

  switch (action.type) {
    case "leave":
      return { remove: leaveRoom(room, playerId) };

    case "configure": {
      if (!isHost) throw new GameError("Настройки меняет только хозяин комнаты");
      if (room.phase !== "lobby") throw new GameError("Настройки можно менять только в лобби");
      if (action.mode === "teams") {
        resizeSeats(room, 4);
        room.settings.mode = "teams";
      } else if (action.mode === "ffa") {
        room.settings.mode = "ffa";
      }
      if (action.seatCount !== undefined) {
        if (room.settings.mode === "teams") throw new GameError("В командном режиме всегда 4 места");
        resizeSeats(room, clampSeats(action.seatCount));
      }
      if (action.stacking !== undefined) room.settings.stacking = action.stacking;
      if (action.botLevel) room.settings.botLevel = action.botLevel;
      return { remove: false };
    }

    case "preset": {
      if (!isHost) throw new GameError("Только хозяин комнаты может менять места");
      if (room.phase !== "lobby") throw new GameError("Это можно делать только в лобби");
      const mode: Mode = action.mode === "teams" ? "teams" : "ffa";
      const count = mode === "teams" ? 4 : clampSeats(action.seatCount);
      resizeSeats(room, count);
      room.settings.mode = mode;
      for (let i = 0; i < room.seats.length; i++) {
        const seat = room.seats[i];
        if (seat.kind === "human") continue;
        const wantOpen = action.open.includes(i);
        if (wantOpen && seat.kind !== "open") room.seats[i] = makeOpenSeat();
        if (!wantOpen && seat.kind !== "bot") room.seats[i] = makeBotSeat(room);
      }
      return { remove: false };
    }

    case "seat": {
      if (!isHost) throw new GameError("Только хозяин комнаты может менять места");
      if (room.phase !== "lobby") throw new GameError("Это можно делать только в лобби");
      if (action.index < 0 || action.index >= room.seats.length) throw new GameError("Нет такого места");
      if (action.index === me) throw new GameError("Это ваше место");
      room.seats[action.index] = action.kind === "bot" ? makeBotSeat(room) : makeOpenSeat();
      return { remove: false };
    }

    case "sit": {
      if (room.phase !== "lobby") throw new GameError("Пересесть можно только в лобби");
      if (action.index < 0 || action.index >= room.seats.length) throw new GameError("Нет такого места");
      if (room.seats[action.index].kind === "human") throw new GameError("Место занято");
      const mine = room.seats[me];
      room.seats[me] = makeOpenSeat();
      room.seats[action.index] = mine;
      return { remove: false };
    }

    case "start": {
      if (!isHost) throw new GameError("Начать игру может только хозяин комнаты");
      if (room.phase !== "lobby") throw new GameError("Игра уже идёт");
      startFromLobby(room, now);
      return { remove: false };
    }

    case "rematch": {
      if (!isHost) throw new GameError("Только хозяин комнаты может начать заново");
      if (room.phase !== "finished") throw new GameError("Партия ещё не закончена");
      room.phase = "lobby";
      room.game = null;
      room.events = [];
      for (let i = 0; i < room.seats.length; i++) {
        if (room.seats[i].kind === "bot" && room.seats[i].name.endsWith("(бот)")) {
          room.seats[i] = makeBotSeat(room);
        }
      }
      if (action.startNow) startFromLobby(room, now);
      return { remove: false };
    }

    case "play": {
      playCard(room, me, action.cardId, action.color);
      scheduleBot(room, now);
      return { remove: false };
    }

    case "draw": {
      drawAction(room, me);
      scheduleBot(room, now);
      return { remove: false };
    }

    case "pass": {
      passAction(room, me);
      scheduleBot(room, now);
      return { remove: false };
    }
  }
}

/* ---------------- Боты ---------------- */

export function isBotDue(room: RoomState, now: number): boolean {
  if (room.phase !== "playing" || !room.game) return false;
  const seat = room.seats[room.game.current];
  if (!seat) return false;
  const controlled = seat.kind !== "human" || now - seat.lastSeen > AWAY_MS;
  return controlled && now >= room.nextBotAt;
}

/** Делает один ход за бота (или за отключившегося игрока). Возвращает true, если ход сделан. */
export function runBot(room: RoomState, now: number): boolean {
  if (!isBotDue(room, now)) return false;
  const seat = room.game!.current;
  const move = chooseBotMove(room, seat);
  try {
    if (move.type === "play") playCard(room, seat, move.cardId, move.color);
    else if (move.type === "draw") drawAction(room, seat);
    else passAction(room, seat);
  } catch {
    try {
      drawAction(room, seat);
    } catch {
      try {
        passAction(room, seat);
      } catch {
        /* ничего не поделать */
      }
    }
  }
  scheduleBot(room, now);
  return true;
}

/** Обновляет "last seen". Возвращает true, если что-то поменялось. */
export function touchSeat(room: RoomState, playerId: string | null | undefined, now: number): boolean {
  const idx = findSeat(room, playerId);
  if (idx < 0) return false;
  room.seats[idx].lastSeen = now;
  return true;
}

/* ---------------- Представление для клиента ---------------- */

const COLOR_ORDER: Record<CardColor, number> = { red: 0, yellow: 1, green: 2, blue: 3, wild: 4 };
const VALUE_ORDER = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "skip", "reverse", "draw2", "wild", "wild4"];

function sortHand(hand: Card[]): Card[] {
  return hand
    .slice()
    .sort((a, b) => COLOR_ORDER[a.color] - COLOR_ORDER[b.color] || VALUE_ORDER.indexOf(a.value) - VALUE_ORDER.indexOf(b.value));
}

export function buildView(room: RoomState, version: number, playerId: string | null | undefined): RoomView {
  const now = Date.now();
  const youSeat = findSeat(room, playerId);
  const g = room.game;
  const hostSeat = room.seats.findIndex((s) => s.kind === "human" && s.playerId === room.hostId);

  const seats = room.seats.map((s, i) => ({
    index: i,
    kind: s.kind,
    name: s.name,
    team: teamOf(room, i),
    cardCount: g ? (g.hands[i]?.length ?? 0) : 0,
    isHost: i === hostSeat,
    isYou: i === youSeat,
    away: s.kind === "human" && now - s.lastSeen > AWAY_BADGE_MS,
  }));

  let gameView: RoomView["game"] = null;
  if (g) {
    const myTurn = room.phase === "playing" && youSeat >= 0 && g.current === youSeat;
    gameView = {
      current: g.current,
      direction: g.direction,
      color: g.color as Color,
      penalty: g.penalty,
      top: topCard(g),
      drawCount: g.drawPile.length,
      hand: youSeat >= 0 ? sortHand(g.hands[youSeat]) : [],
      playable: youSeat >= 0 ? playableIds(room, youSeat) : [],
      canDraw: myTurn && g.drawn === null,
      canPass: myTurn && g.drawn !== null,
      drawnId: myTurn ? g.drawn : null,
      winner: g.winner,
      winnerTeam: g.winnerTeam,
      points: g.points,
      turnSeq: g.turnSeq,
      finalHands: room.phase === "finished" ? g.hands.map(sortHand) : null,
    };
  }

  const awaySig = seats.map((s) => (s.away ? "1" : "0")).join("");
  return {
    code: room.code,
    stamp: `${version}:${awaySig}`,
    phase: room.phase,
    settings: room.settings,
    youSeat: youSeat >= 0 ? youSeat : null,
    hostSeat,
    seats,
    game: gameView,
    events: room.events,
  };
}

/* ---------------- Разбор запроса ---------------- */

const LEVELS: BotLevel[] = ["easy", "normal", "hard"];
const COLOR_LIST: Color[] = ["red", "yellow", "green", "blue"];

function int(v: unknown): number | null {
  return typeof v === "number" && Number.isFinite(v) ? Math.floor(v) : null;
}

export function parseAction(raw: unknown): ClientAction | null {
  if (!raw || typeof raw !== "object") return null;
  const a = raw as Record<string, unknown>;
  switch (a.type) {
    case "join":
      return typeof a.name === "string" ? { type: "join", name: a.name } : null;
    case "leave":
      return { type: "leave" };
    case "start":
      return { type: "start" };
    case "draw":
      return { type: "draw" };
    case "pass":
      return { type: "pass" };
    case "configure": {
      const out: Extract<ClientAction, { type: "configure" }> = { type: "configure" };
      if (a.mode === "ffa" || a.mode === "teams") out.mode = a.mode;
      const seatCount = int(a.seatCount);
      if (seatCount !== null) out.seatCount = seatCount;
      if (typeof a.stacking === "boolean") out.stacking = a.stacking;
      if (typeof a.botLevel === "string" && LEVELS.includes(a.botLevel as BotLevel)) {
        out.botLevel = a.botLevel as BotLevel;
      }
      return out;
    }
    case "preset": {
      const seatCount = int(a.seatCount);
      if ((a.mode !== "ffa" && a.mode !== "teams") || seatCount === null || !Array.isArray(a.open)) return null;
      const open = a.open.map(int).filter((n): n is number => n !== null);
      return { type: "preset", mode: a.mode, seatCount, open };
    }
    case "seat": {
      const index = int(a.index);
      if (index === null || (a.kind !== "open" && a.kind !== "bot")) return null;
      return { type: "seat", index, kind: a.kind };
    }
    case "sit": {
      const index = int(a.index);
      return index === null ? null : { type: "sit", index };
    }
    case "rematch":
      return { type: "rematch", startNow: a.startNow === true };
    case "play": {
      const cardId = int(a.cardId);
      if (cardId === null) return null;
      const color = COLOR_LIST.includes(a.color as Color) ? (a.color as Color) : undefined;
      return { type: "play", cardId, color };
    }
    default:
      return null;
  }
}

export { isPlayable };
