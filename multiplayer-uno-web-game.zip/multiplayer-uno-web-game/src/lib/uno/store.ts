import { and, eq, lt } from "drizzle-orm";
import { db } from "@/db";
import { rooms } from "@/db/schema";
import { GameError } from "./engine";
import {
  applyAction,
  buildView,
  createRoomState,
  findSeat,
  isBotDue,
  runBot,
  touchSeat,
} from "./room";
import type { ClientAction, RoomState, RoomView } from "./types";

const CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
const ROOM_TTL_MS = 12 * 60 * 60 * 1000;

export { GameError };

function makeCode(): string {
  let code = "";
  for (let i = 0; i < 5; i++) code += CODE_ALPHABET[Math.floor(Math.random() * CODE_ALPHABET.length)];
  return code;
}

export function normalizeCode(raw: string): string {
  return raw.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 8);
}

export async function createRoom(hostId: string, hostName: string): Promise<string> {
  const now = Date.now();
  // Подчищаем давно заброшенные комнаты
  await db.delete(rooms).where(lt(rooms.touchedAt, now - ROOM_TTL_MS));

  for (let attempt = 0; attempt < 10; attempt++) {
    const code = makeCode();
    const state = createRoomState(code, hostId, hostName, now);
    const inserted = await db
      .insert(rooms)
      .values({ code, state, version: 1, touchedAt: now })
      .onConflictDoNothing()
      .returning({ code: rooms.code });
    if (inserted.length > 0) return code;
  }
  throw new GameError("Не удалось создать комнату, попробуйте ещё раз");
}

interface Outcome<T> {
  changed: boolean;
  result: T;
  remove?: boolean;
}

interface Mutated<T> {
  result: T;
  room: RoomState | null;
  version: number;
}

async function mutateRoom<T>(code: string, fn: (room: RoomState) => Outcome<T>): Promise<Mutated<T> | null> {
  return db.transaction(async (tx) => {
    const [row] = await tx.select().from(rooms).where(eq(rooms.code, code)).limit(1).for("update");
    if (!row) return null;
    const room = row.state;
    const out = fn(room); // если здесь исключение — транзакция откатывается
    if (out.remove) {
      await tx.delete(rooms).where(eq(rooms.code, code));
      return { result: out.result, room: null, version: row.version };
    }
    const version = out.changed ? row.version + 1 : row.version;
    await tx
      .update(rooms)
      .set({ state: room, version, ...(out.changed ? { touchedAt: Date.now() } : {}) })
      .where(eq(rooms.code, code));
    return { result: out.result, room, version };
  });
}

/** Состояние комнаты глазами конкретного игрока. Заодно "двигает" ботов. */
export async function getRoomView(code: string, playerId: string | null): Promise<RoomView | null> {
  const [row] = await db
    .select()
    .from(rooms)
    .where(and(eq(rooms.code, code)))
    .limit(1);
  if (!row) return null;

  let room = row.state;
  let version = row.version;
  const now = Date.now();

  const seatIdx = findSeat(room, playerId);
  const needsTouch = seatIdx >= 0 && now - room.seats[seatIdx].lastSeen > 4000;

  if (needsTouch || isBotDue(room, now)) {
    const res = await mutateRoom(code, (r) => {
      touchSeat(r, playerId, now);
      const moved = runBot(r, now);
      return { changed: moved, result: null };
    });
    if (!res) return null;
    if (res.room) {
      room = res.room;
      version = res.version;
    }
  }

  return buildView(room, version, playerId);
}

export interface ActionResult {
  view: RoomView | null;
}

export async function performAction(
  code: string,
  playerId: string,
  action: ClientAction,
): Promise<ActionResult | null> {
  const now = Date.now();
  const res = await mutateRoom(code, (room) => {
    const outcome = applyAction(room, playerId, action, now);
    return { changed: true, result: null, remove: outcome.remove };
  });
  if (!res) return null;
  if (!res.room) return { view: null };
  return { view: buildView(res.room, res.version, playerId) };
}
