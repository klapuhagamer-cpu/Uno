export type Color = "red" | "yellow" | "green" | "blue";
export type CardColor = Color | "wild";
export type CardValue =
  | "0"
  | "1"
  | "2"
  | "3"
  | "4"
  | "5"
  | "6"
  | "7"
  | "8"
  | "9"
  | "skip"
  | "reverse"
  | "draw2"
  | "wild"
  | "wild4";

export interface Card {
  id: number;
  color: CardColor;
  value: CardValue;
}

export type Mode = "ffa" | "teams";
export type BotLevel = "easy" | "normal" | "hard";

export interface Settings {
  mode: Mode;
  seatCount: number;
  /** Можно ли "складывать" +2 на +2 и +4 на штраф */
  stacking: boolean;
  botLevel: BotLevel;
}

export type SeatKind = "human" | "bot" | "open";

export interface Seat {
  kind: SeatKind;
  name: string;
  /** Секретный токен игрока (никогда не отдаётся клиентам) */
  playerId: string | null;
  lastSeen: number;
}

export interface GameState {
  hands: Card[][];
  drawPile: Card[];
  discard: Card[];
  current: number;
  direction: 1 | -1;
  color: Color;
  /** Накопленный штраф (только при включённом stacking) */
  penalty: number;
  /** id карты, которую игрок только что взял и может сыграть (иначе пас) */
  drawn: number | null;
  winner: number | null;
  winnerTeam: number | null;
  points: number;
  turnSeq: number;
}

export type EventType =
  | "play"
  | "draw"
  | "skip"
  | "reverse"
  | "penalty"
  | "uno"
  | "win"
  | "start"
  | "info";

export interface GameEvent {
  id: number;
  type: EventType;
  seat: number | null;
  text: string;
}

export type Phase = "lobby" | "playing" | "finished";

export interface RoomState {
  code: string;
  hostId: string;
  phase: Phase;
  settings: Settings;
  seats: Seat[];
  game: GameState | null;
  events: GameEvent[];
  eventSeq: number;
  /** Когда бот (или отсутствующий игрок) может сделать следующий ход */
  nextBotAt: number;
}

/* ---------- То, что видит клиент ---------- */

export interface SeatView {
  index: number;
  kind: SeatKind;
  name: string;
  team: number | null;
  cardCount: number;
  isHost: boolean;
  isYou: boolean;
  /** Игрок давно не выходил на связь */
  away: boolean;
}

export interface GameView {
  current: number;
  direction: 1 | -1;
  color: Color;
  penalty: number;
  top: Card;
  drawCount: number;
  hand: Card[];
  playable: number[];
  canDraw: boolean;
  canPass: boolean;
  drawnId: number | null;
  winner: number | null;
  winnerTeam: number | null;
  points: number;
  turnSeq: number;
  /** Руки всех игроков — только когда игра закончена */
  finalHands: Card[][] | null;
}

export interface RoomView {
  code: string;
  stamp: string;
  phase: Phase;
  settings: Settings;
  youSeat: number | null;
  hostSeat: number;
  seats: SeatView[];
  game: GameView | null;
  events: GameEvent[];
}

export type ClientAction =
  | { type: "join"; name: string }
  | { type: "leave" }
  | {
      type: "configure";
      mode?: Mode;
      seatCount?: number;
      stacking?: boolean;
      botLevel?: BotLevel;
    }
  | { type: "preset"; mode: Mode; seatCount: number; open: number[] }
  | { type: "seat"; index: number; kind: "open" | "bot" }
  | { type: "sit"; index: number }
  | { type: "start" }
  | { type: "rematch"; startNow: boolean }
  | { type: "play"; cardId: number; color?: Color }
  | { type: "draw" }
  | { type: "pass" };
